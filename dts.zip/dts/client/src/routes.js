import React from 'react';
//Admin dashboard

const Drivers = React.lazy(() => import('./views/Admin/Drivers'));
const Dashboard = React.lazy(() => import('./views/Admin/Dashboard'));
const Passengers = React.lazy(() => import('./views/Admin/Passengers'));
const Complaints = React.lazy(() => import('./views/Admin/Complaints'));
const Payments = React.lazy(() => import('./views/Admin/Payments'));
const Location = React.lazy(() => import('./views/Admin/Location'));
const Settings = React.lazy(() => import('./views/Admin/Settings'));
const EditProfile = React.lazy(() => import('./views/Admin/EditProfile'));

//End Admin Dashboard

//Driver Dashboard
const DriverNotification = React.lazy(() =>
  import('./views/Driver/DriverNotification')
);
const DriverDashboard = React.lazy(() =>
  import('./views/Driver/DriverDashboard')
);
const DriverMessages = React.lazy(() =>
  import('./views/Driver/DriverMessages')
);
const DriverPassengers = React.lazy(() =>
  import('./views/Driver/DriverPassengers')
);
const DriverUpdateLocation = React.lazy(() =>
  import('./views/Driver/DriverUpdateLocation')
);
const DriverUpdateTime = React.lazy(() =>
  import('./views/Driver/DriverUpdateTime')
);
const CarSetting = React.lazy(() => import('./views/Driver/CarSetting'));
const DriverComplaints = React.lazy(() =>
  import('./views/Driver/DriverComplaints')
);
const Startride = React.lazy(() => import('./views/Driver/Startride'));
const Driverupdate = React.lazy(() =>
  import('./views/Driver/Driverupdate/Driverupdate')
);
// const EditProfileAdmin = React.lazy(() =>
//   import('./views/Admin/EditProfile/index')
// );
//End Driver Dashboard

//Passenger Dashboard
const PassengerNotification = React.lazy(() =>
  import('./views/Passenger/PassengerNotification')
);
const PassengerDashboard = React.lazy(() =>
  import('./views/Passenger/PassengerDashboard')
);
const PassengerMessages = React.lazy(() =>
  import('./views/Passenger/PassengerMessages')
);
const PassengerBookings = React.lazy(() =>
  import('./views/Passenger/PassengerBookings')
);
const PassengerPayments = React.lazy(() =>
  import('./views/Passenger/PassengerPayments')
);
const PassengerFeedback = React.lazy(() =>
  import('./views/Passenger/PassengerFeedback/index1')
);
const PassengerComplaints = React.lazy(() =>
  import('./views/Passenger/PassengerComplaints')
);

const Passengerupdate = React.lazy(() =>
  import('./views/Passenger/Passengerupdate/Passengerupdate')
);

//Chat Component

const Chat = React.lazy(() => import('./views/Chat/index'));

//End Passenger Dashboard

// https://github.com/ReactTraining/react-router/tree/master/packages/react-router-config
const routes = [
  // { path: "/", name: "Home" },
  // Admin Dashboard

  {
    path: '/admin-dashboard',
    name: 'Dashboard',
    component: Dashboard,
  },
  {
    path: '/drivers',
    exact: true,
    name: 'Drivers',
    component: Drivers,
  },
  {
    path: '/passengers',
    exact: true,
    name: 'Passengers',
    component: Passengers,
  },
  {
    path: '/complaints',
    exact: true,
    name: 'Passengers',
    component: Complaints,
  },
  {
    path: '/payments',
    exact: true,
    name: 'Payments',
    component: Payments,
  },
  {
    path: '/location',
    exact: true,
    name: 'Location',
    component: Location,
  },
  {
    path: '/settings',
    exact: true,
    name: 'Settings',
    component: Settings,
  },
  {
    path: '/admin-edit-profile',
    name: 'Edit Profile',
    component: EditProfile,
  },

  // End Admin Dashboard
  // Driver Dashboard
  {
    path: '/notifications',
    exact: true,
    name: 'DriverNotification',
    component: DriverNotification,
  },
  {
    path: '/start-ride',
    exact: true,
    name: 'Startride',
    component: Startride,
  },
  {
    path: '/driver-dashboard',
    exact: true,
    name: 'DriverDashboard',
    component: DriverDashboard,
  },
  {
    path: '/messages',
    exact: true,
    name: 'DriverMessages',
    component: DriverMessages,
  },
  {
    path: '/passenger',
    exact: true,
    name: 'DriverPassengers',
    component: DriverPassengers,
  },
  {
    path: '/updatelocation',
    exact: true,
    name: 'DriverUpdateLocation',
    component: DriverUpdateLocation,
  },
  {
    path: '/updatetime',
    exact: true,
    name: 'DriverUpdateTime',
    component: DriverUpdateTime,
  },
  {
    path: '/setting',
    exact: true,
    name: 'CarSetting',
    component: CarSetting,
  },
  {
    path: '/complaint',
    exact: true,
    name: 'DriverComplaints',
    component: DriverComplaints,
  },

  {
    path: '/update-profile',
    exact: true,
    name: 'Driverupdate',
    component: Driverupdate,
  },

  // End Driver Dashboard
  // Passenger Dashboard
  {
    path: '/passenger-notifications',
    exact: true,
    name: 'PassengerNotification',
    component: PassengerNotification,
  },
  {
    path: '/passenger-dashboard',
    exact: true,
    name: 'PassengerDashboard',
    component: PassengerDashboard,
  },
  {
    path: '/passenger-messages',
    exact: true,
    name: 'PassengerMessages',
    component: PassengerMessages,
  },
  {
    path: '/passenger-bookings',
    exact: true,
    name: 'PassengerBookings',
    component: PassengerBookings,
  },
  {
    path: '/passenger-payments',
    exact: true,
    name: 'PassengerPayments',
    component: PassengerPayments,
  },
  {
    path: '/passenger-feedback',
    exact: true,
    name: 'PassengerFeedback',
    component: PassengerFeedback,
  },
  {
    path: '/passenger-complaints',
    exact: true,
    name: 'PassengerComplaints',
    component: PassengerComplaints,
  },
  {
    path: '/chat',
    exact: true,
    name: 'chat',
    component: Chat,
  },

  {
    path: '/chat/:email',
    exact: true,
    name: 'chat',
    component: Chat,
  },
  {
    path: '/passenger-update-profile',
    exact: true,
    name: 'Passengerupdate',
    component: Passengerupdate,
  },

  // {
  //   path: '/edit_profile/:id',
  //   exact: true,
  //   name: 'chat',
  //   component: EditProfileAdmin,
  // },

  // End Passenger Dashboard
];
export default routes;
