export default {
  items: [
    {
      name: 'Passenger Dashboard',
      url: '/passenger-dashboard/passenger-dashboard',
      // icon: 'cui-dashboard',
      attributes: {
        exact: true,
      },
    },
    {
      name: 'Book Ride',
      url: '/passenger-dashboard/passenger-bookings',
      // icon: 'cui-bell',
      attributes: {
        exact: true,
      },
    },
    {
      name: 'Available Drivers',
      url: '/passenger-dashboard/passenger-messages',
      // icon: 'cui-envelope-closed',
      attributes: {
        exact: true,
      },
    },
    {
      name: 'My Rides',
      url: '/passenger-dashboard/passenger-notifications',
      // icon: 'cui-list',
      attributes: {
        exact: true,
      },
    },
    {
      name: 'Payment',
      url: '/passenger-dashboard/passenger-payments',
      // icon: 'cui-dollar',
      attributes: {
        exact: true,
      },
    },

    {
      name: 'Chat',
      url: '/passenger-dashboard/chat/:email',
      // icon: 'ccui-envelope-closed',
      attributes: {
        exact: true,
      },
    },
    // // {
    // //   name: "Feedback",
    // //   url: "/passenger-dashboard/passenger-feedback",
    // //   icon: "cui-pencil",
    // //   attributes: {
    // //     exact: true
    // //   }
    // // },
    // {
    //   name: "Complaints",
    //   url: "/passenger-dashboard/passenger-complaints",
    //   icon: "cui-pencil",
    //   attributes: {
    //     exact: true
    //   }
  ],
};
