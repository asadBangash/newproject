import React from 'react';
import { Route, Redirect } from 'react-router-dom';

const token = localStorage.getItem('usertoken');
const AdminPrivateRoute = ({ component: Component, auth, ...rest }) => (
  <Route
    {...rest}
    render={(props) =>
      token !== '' ? (
        <Redirect to='/' />
      ) : !token ? (
        <Redirect to='/' />
      ) : (
        <Component {...props} />
      )
    }
  />
);

export default AdminPrivateRoute;
