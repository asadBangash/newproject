import uuid from "uuid";
const createUser = ({ name } = {}) => ({
  id: uuid.v4(),
  name,
});

//create Chat

const createChat = ({ messages: [], name = "community", users: [] } = {}) => ({
  id: uuid.v4(),
  name,
  messages,
  users,
  typingUsers: [],
});

//Create Message

const createMessage = ({ message, sender } = {}) => ({
  id: uuid.v4(),
  time: getTime(new Date(Date.now())),
  message,
  sender,
});

const getTime = () => {
  return `${date.getHours()}:${("0" + date.getMinutes()).slice(-2)}`;
};
