import React, { Component } from 'react';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
// import { renderRoutes } from 'react-router-config';
import './App.scss';
import PrivateRoute from './PrivateRoutes';
import EditProfile from './views/Admin/EditProfile/index';
const loading = () => (
  <div className='animated fadeIn pt-3 text-center'>Loading...</div>
);
// Containers
const AdminDashboard = React.lazy(() => import('./containers/AdminDashboard'));
const DriverDashboard = React.lazy(() =>
  import('./containers/DriverDashboard')
);
const PassengerDashboard = React.lazy(() =>
  import('./containers/PassengerDashboard')
);
// Pages
const Driverlogin = React.lazy(() =>
  import('./views/Pages/Driverlogin/Driverlogin')
);
const Driversuccess = React.lazy(() => import('./views/Pages/Driversuccess'));
const Adminlogin = React.lazy(() =>
  import('./views/Pages/Adminlogin/Adminlogin')
);
const Adminsuccess = React.lazy(() => import('./views/Pages/Adminsuccess'));
const Passengerlogin = React.lazy(() =>
  import('./views/Pages/Passengerlogin/Passengerlogin')
);
const Passengersuccess = React.lazy(() =>
  import('./views/Pages/Passengersuccess')
);
const Driverchoose = React.lazy(() => import('./views/Pages/Driverchoose'));
const Passengerchoose = React.lazy(() =>
  import('./views/Pages/Passengerchoose')
);
const Registerdriver = React.lazy(() => import('./views/Pages/Registerdriver'));
const Registeradmin = React.lazy(() => import('./views/Pages/Registeradmin'));
const Registerpassenger = React.lazy(() =>
  import('./views/Pages/Registerpassenger')
);
const Forgetpassword = React.lazy(() => import('./views/Pages/Forgetpassword'));
const Landing = React.lazy(() => import('./views/Pages/Landing'));
const Page404 = React.lazy(() => import('./views/Pages/Page404'));
const Page500 = React.lazy(() => import('./views/Pages/Page500'));
const Chat = React.lazy(() => import('./views/Chat/index'));

class App extends Component {
  state = {
    isAuth: false,
  };
  render() {
    return (
      <BrowserRouter>
        <React.Suspense fallback={loading()}>
          <Switch>
            <Route
              path='/admin-dashboard/edit_profile/:id'

              // render={(props) => <EditProfileAdmin {...props} />}
              component={EditProfile}
            />
            <Route
              exact
              path='/driverchoose'
              name='driverchoose'
              render={(props) => <Driverchoose {...props} />}
            />
            <Route
              exact
              path='/adminlogin'
              name='Login Page'
              render={(props) => <Adminlogin {...props} />}
            />
            <Route
              exact
              path='/adminsuccess'
              name='Success Page'
              render={(props) => <Adminsuccess {...props} />}
            />
            <Route
              exact
              path='/driverlogin'
              name='Login Page'
              render={(props) => <Driverlogin {...props} />}
            />
            <Route
              exact
              path='/driversuccess'
              name='Success Page'
              render={(props) => <Driversuccess {...props} />}
            />
            <Route
              exact
              path='/passengersuccess'
              name='Success Page'
              render={(props) => <Passengersuccess {...props} />}
            />
            <Route
              exact
              path='/registerdriver'
              name='Registerdriver'
              render={(props) => <Registerdriver {...props} />}
            />
            <Route
              exact
              path='/registeradmin'
              name='Registeradmin'
              render={(props) => <Registeradmin {...props} />}
            />
            <Route
              exact
              path='/passengerchoose'
              name='passengerchoose'
              render={(props) => <Passengerchoose {...props} />}
            />
            <Route
              exact
              path='/passengerlogin'
              name='Login Page'
              render={(props) => <Passengerlogin {...props} />}
            />
            <Route
              exact
              path='/registerpassenger'
              name='Registerpassenger'
              render={(props) => <Registerpassenger {...props} />}
            />
            <Route
              exact
              path='/forgetpassword'
              name='Forgetpassword'
              render={(props) => <Forgetpassword {...props} />}
            />
            {/* <Route exact path="/register" name="Register Page" render={props => <Register {...props}/>} /> */}
            <Route
              exact
              path='/404'
              name='Page 404'
              render={(props) => <Page404 {...props} />}
            />
            <Route
              exact
              path='/500'
              name='Page 500'
              render={(props) => <Page500 {...props} />}
            />
            <Route
              path='/driver-dashboard'
              name='DriverDashboard'
              component={DriverDashboard}
            />

            <Route
              path='/passenger-dashboard'
              name='PassengerDashboard'
              render={(props) => <PassengerDashboard {...props} />}
              component={PassengerDashboard}
            />

            <Route
              path='/admin-dashboard'
              name='AdminDashboard'
              render={(props) => <AdminDashboard {...props} />}
              component={AdminDashboard}
            />
            {/* <Route
              path="/landing"
              name="Landing"
              render={props => <Landing {...props} />}
            /> */}
            <Route
              path='/'
              name='Home'
              render={(props) => <Landing {...props} />}
            />
            <Route
              path='/passenger-dashboard/chat/:email'
              exact
              render={(props) => <Chat {...props} />}
            // component={Chat}
            />



            {/* <Route
              path='/admin-dashboard/edit_profile/:id'
              exact
              // render={(props) => <EditProfileAdmin {...props} />}
              component={EditProfile}
            /> */}
          </Switch>
        </React.Suspense>
      </BrowserRouter>
    );
  }
}
export default App;
