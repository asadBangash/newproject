// import React, { Component } from 'react';
// import GoogleMapReact from 'google-map-react';
 

// import {
//   Badge,
//   Button,
//   Card,
//   CardBody,
//   CardFooter,
//   CardHeader,
//   Col,
//   Collapse,
//   DropdownItem,
//   DropdownMenu,
//   DropdownToggle,
//   Fade,
//   Form,
//   FormGroup,
//   FormText,
//   FormFeedback,
//   Input,
//   InputGroup,
//   InputGroupAddon,
//   InputGroupButtonDropdown,
//   InputGroupText,
//   Label,
//   Row,
// } from 'reactstrap';

// const AnyReactComponent = ({ text }) => <div>{text}</div>;

// class PassengerBookings extends Component {
//   constructor(props) {
//     super(props);

//     this.toggle = this.toggle.bind(this);
//     this.toggleFade = this.toggleFade.bind(this);
//     this.state = {
//       collapse: true,
//       fadeIn: true,
//       timeout: 300
//     };
//   }

//   toggle() {
//     this.setState({ collapse: !this.state.collapse });
//   }

//   toggleFade() {
//     this.setState((prevState) => { return { fadeIn: !prevState }});
//   }

//   static defaultProps = {
//     center: {
//       lat: 59.95,
//       lng: 30.33
//     },
//     zoom: 11
//   };
 

//   render() {
//     return (
//       <container>
//       <div className="animated fadeIn">
//         <Row>
//         <Col xs="12" sm="6">
//         <Card>
//               <CardHeader>
//                 <strong>Inline</strong> Form
//               </CardHeader>
//               <CardBody>
//                 <center><Form action="" method="post" inline>
//                   <FormGroup className="pr-1">
//                     {/* <Label htmlFor="exampleInputName2" className="pr-1">Name</Label> */}
//                     <Input type="text" id="exampleInputName2" placeholder="Pick up" required />
//                   </FormGroup>
//                   <FormGroup className="pr-1">
//                     {/* <Label htmlFor="exampleInputEmail2" className="pr-1">Email</Label> */}
//                     <Input type="email" id="exampleInputEmail2" placeholder="dropoff" required />
//                   </FormGroup>
//                 </Form></center>
//               </CardBody>
//               {/* <CardFooter>
//                 <Button type="submit" size="sm" color="primary"><i className="fa fa-dot-circle-o"></i> Submit</Button>
//                 <Button type="reset" size="sm" color="danger"><i className="fa fa-ban"></i> Reset</Button>
//               </CardFooter> */}
//             </Card>
//             </Col>
//             </Row>
            
//             <div style={{ height: '100vh', width: '100%' }}>
//         <GoogleMapReact
//           // bootstrapURLKeys={{ key: /* YOUR KEY HERE */ }}
//           defaultCenter={this.props.center}
//           defaultZoom={this.props.zoom}
//         >
//           <AnyReactComponent
//             lat={59.955413}
//             lng={30.337844}
//             text="My Marker"
//           />
//         </GoogleMapReact>
//       </div>
            
//       </div>
//       </container>
//     );
//   }
// }

// export default PassengerBookings;




import React, { useEffect, useState } from "react";
import GoogleMapReact from "google-map-react";
import { faCoffee } from "@fortawesome/free-solid-svg-icons";
import "./style.css";
import Marker from "./marker";
const AnyReactComponent = ({ text }) => (
  <div
    className='pin'
    style={{ backgroundColor: "red", cursor: "pointer" }}
  ></div>
);

const Location = (props) => {
  const [driverId, setDriverId] = useState("");
  const [locations, setLocations] = useState([]);
  let pickUpLatitude = 0;
  let pickUpLongitude = 0;
  let dropOffLatitude = 0;
  let dropOffLongitude = 0;

  const getLocation = async () => {
    try {
      const id = parseInt(window.localStorage.getItem("driverId"));
      const response = await fetch(`http://localhost:5000/location/${id}`, {
        method: "GET",
      });

      let parseData = await response.json();
      console.log(parseData[0].select_pickup_location);
      console.log(parseData[0].select_dropoff_location);

      if (parseData[0].select_pickup_location == "Gujrat") {
        pickUpLatitude = 32.574935;
        pickUpLongitude = 74.0195651;
      }

      if (parseData[0].select_dropoff_location == "Lahore") {
        dropOffLatitude = 31.52037;
        dropOffLongitude = 74.358749;
      }

      console.log(`${pickUpLatitude}, ${pickUpLongitude}`);
      console.log(`${dropOffLatitude}, ${dropOffLongitude}`);
    } catch (error) {
      console.error(error.message);
      console.log("Error in getting locations");
    }
  };

  const getDriverId = () => {
    setDriverId(parseInt(window.localStorage.getItem("driverId")));
    getLocation(driverId);
  };

  useEffect(() => {
    getDriverId();
  }, []);

  const getMapOptions = (maps) => {
    return {
      disableDefaultUI: true,
      mapTypeControl: true,
      streetViewControl: true,
      styles: [
        {
          featureType: "poi",
          elementType: "labels",
          stylers: [{ visibility: "on" }],
        },
      ],
    };
  };

  return (
    // Important! Always set the container height explicitly

    <GoogleMapReact
      defaultCenter={{
        lat: 32.574935,
        lng: 74.0195651,
      }}
      defaultZoom={11}
      style={{ width: "500px", height: "300px" }}
    >
      <AnyReactComponent lat={32.574935} lng={74.0195651} text={"Pick Up"} />
      <AnyReactComponent lat={31.52037} lng={74.358749} text={"Pick Up"} />
    </GoogleMapReact>
  );
};

export default Location;
