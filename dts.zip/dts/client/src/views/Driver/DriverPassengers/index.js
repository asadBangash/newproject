import React, { Component } from 'react';
import { Badge, Card, CardBody, CardHeader, Col, Pagination, PaginationItem, PaginationLink, Row, Table } from 'reactstrap';

class DriverPassengers extends Component {
  render() {
    return (
      <div className="animated fadeIn">
        <Row>
          

          <Col>
            <Card>
              <CardHeader>
                <i className="fa fa-align-justify"></i> Passengers
              </CardHeader>
              <CardBody>
                <Table responsive striped>
                  <thead>
                  <tr>
                    <th>S.No</th>
                    <th>Username</th>
                    <th>Location</th>
                    <th>Contact</th>
                    <th>Status</th>
                    
                    
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td>01</td>
                    <td>M Omar</td>
                    <td>Peshawar</td>
                    
                    <td>03339666555</td>
                    <td>
                      <Badge color="success">Active</Badge>
                    </td>
                    
                  </tr>
                  <tr>
                    <td>02</td>
                    <td>Saqib</td>
                    <td>Saddar</td>
                    
                    <td>03339666555</td>
                    <td>
                      <Badge color="danger">Banned</Badge>
                    </td>
                    
                  </tr>
                  <tr>
                    <td>03</td>
                    <td>Javed</td>
                    <td>Board</td>
                    
                    <td>03339666555</td>
                    <td>
                      <Badge color="secondary">Inactive</Badge>
                    </td>
                    
                  </tr>
                  <tr>
                    <td>04</td>
                    <td>Asad</td>
                    <td>RingRoad</td>
                    
                    <td>03339666555</td>
                    <td>
                      <Badge color="warning">Pending</Badge>
                    </td>
                    
                  </tr>
                  <tr>
                  <td>05</td>
                    <td>kamran</td>
                    <td>Hayatabad</td>
                    
                    <td>03339666555</td>
                    <td>
                      <Badge color="success">Active</Badge>
                    </td>
                    
                  </tr>
                  </tbody>
                </Table>
                <Pagination>
                  <PaginationItem disabled><PaginationLink previous tag="button">Prev</PaginationLink></PaginationItem>
                  <PaginationItem active>
                    <PaginationLink tag="button">1</PaginationLink>
                  </PaginationItem>
                  <PaginationItem><PaginationLink tag="button">2</PaginationLink></PaginationItem>
                  <PaginationItem><PaginationLink tag="button">3</PaginationLink></PaginationItem>
                  <PaginationItem><PaginationLink tag="button">4</PaginationLink></PaginationItem>
                  <PaginationItem><PaginationLink next tag="button">Next</PaginationLink></PaginationItem>
                </Pagination>
              </CardBody>
            </Card>
          </Col>
        </Row>

        

      </div>

    );
  }
}

export default DriverPassengers;
