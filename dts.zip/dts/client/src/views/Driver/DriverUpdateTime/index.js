import React from 'react'

/**
* @author
* @function DriverUpdateTime
**/

const DriverUpdateTime = (props) => {
  return(
    <div>DriverUpdateTime</div>
   )

 }

export default DriverUpdateTime