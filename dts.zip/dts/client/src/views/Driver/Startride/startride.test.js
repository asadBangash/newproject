import React from 'react';
import ReactDOM from 'react-dom';
import Startride from './Startride';

it('renders without crashing', () => {
  const div = document.createElement('div');
  ReactDOM.render(<Startride />, div);
  ReactDOM.unmountComponentAtNode(div);
});
