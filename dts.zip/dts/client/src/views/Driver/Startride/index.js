import React from "react";
import Axios from 'axios';
import PlacesAutocomplete, {
  geocodeByAddress,
  getLatLng
} from "react-places-autocomplete";
import { Button, Form, FormGroup, Label, Input, FormText ,Table} from "reactstrap";

const initialState = {
  pickUp: "", dropOf: "", availableSeats: 0, price: 0,trips:null
}

export default class StarttDrive extends React.Component {

componentDidMount(){
  const token = localStorage.getItem('usertoken');
Axios.get('/drivers/driver_rides',{
  headers:{
    'x-auth-token':token
  }
}).then(res=>{
  console.log(res.data);
  this.setState({trips:res.data})
})
}

renderRides = ()=>{
  if(this.state.trips){
 
 return this.state.trips.map((trip)=>{
    return(
      <Table>
      <thead>
        <tr>
          <th>ride_id</th>
          <th>pickupLocation</th>
          <th>dropoffLocation</th>
          <th>numberOfSeats</th>
          <th>totalPrice</th>
          <th>passengerId</th>
        </tr>
      </thead>
      <tbody>
        <tr>
        <th>{trip.ride_id}</th>
        <th>{trip.pickupLocation}</th>
        <th>{trip.dropoffLocation}</th>
        <th>{trip.numberOfSeats}</th>
        <th>{trip.totalPrice}</th>
        <th>{trip.passengerId}</th>
        </tr>
        
      </tbody>
    </Table>
    )
  })
}
}

  constructor(props) {
    super(props);
    this.state = initialState;
  }

  handleChange = pickUp => {
    this.setState({ pickUp });
  };
  handleDropOfChange = dropOf => {
    this.setState({ dropOf });
  };

  validate = () => {
    let pickUpError = "";
    let dropOfError = "";
    let availableSeatsError = "";
    let priceError = "";


    // if(!this.state.email.includes('@')){
    //   emailError = 'invalid email';
    // }

    if (!this.state.pickUp) {
      pickUpError = 'please type pickup';
    }
    if (!this.state.dropOf) {
      dropOfError = 'please type dropOf';
    }
    if (!this.state.availableSeats) {
      availableSeatsError = 'please type availableSeats';
    }
    if (!this.state.price) {
      priceError = 'please type price';
    }

    if (pickUpError || dropOfError || availableSeatsError || priceError) {
      this.setState({ pickUpError, dropOfError, availableSeatsError, priceError });
      return false;
    }
    return true;

  };

  SubmitData = e => {
    e.preventDefault();
    const token = localStorage.getItem("usertoken");
    const isValid = this.validate();
    let data = {
      select_pickup_location: this.state.pickUp,
      select_dropoff_location: this.state.dropOf,
      number_of_seats_available: this.state.availableSeats,
      enter_price: this.state.price,
    }
    if (isValid) {
      Axios.post('http://localhost:5000/startrides/start-ride'
        , data, {
        headers: {
          "x-auth-token": `${token}`,
          "Content-Type": "application/json"
        }
      }).then(res => console.log(res))
      this.setState(initialState);
    }
  }
  handleSelect = pickUp => {
    geocodeByAddress(pickUp)
      .then(results => getLatLng(results[0]))
      .then(latLng => console.log("Success", latLng))
      .catch(error => console.error("Error", error));
  };

  handleDropOfSelect = dropOf => {
    geocodeByAddress(dropOf)
      .then(results => getLatLng(results[0]))
      .then(latLng => console.log("Success", latLng))
      .catch(error => console.error("Error", error));
  };
  render() {
    return (
      <Form
        onSubmit={this.SubmitData}
      >
        <PlacesAutocomplete
          value={this.state.pickUp}
          onChange={this.handleChange}
          onSelect={this.handleSelect}
          googleCallbackName="initOne"
        >
          {({
            getInputProps,
            suggestions,
            getSuggestionItemProps,
            loading
          }) => (
              <div>
                <FormGroup>
                  <Label for="Pickup">Select Pickup Location:</Label>
                  <Input
                    {...getInputProps({
                      placeholder: "",
                      className: "location-search-input"
                    })}
                  />
                  <div style={{ fontSize: 12, color: "red" }}>
                    {this.state.pickUpError}
                  </div>
                </FormGroup>
                <div className="autocomplete-dropdown-container">
                  {loading && <div>Loading...</div>}
                  {suggestions.map(suggestion => {
                    const className = suggestion.active
                      ? "suggestion-item--active"
                      : "suggestion-item";
                    // inline style for demonstration purpose
                    const style = suggestion.active
                      ? { backgroundColor: "#fafafa", cursor: "pointer" }
                      : { backgroundColor: "#ffffff", cursor: "pointer" };
                    return (
                      <div
                        {...getSuggestionItemProps(suggestion, {
                          className,
                          style
                        })}
                      >
                        <span>{suggestion.description}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
        </PlacesAutocomplete>
        <PlacesAutocomplete
          value={this.state.dropOf}
          onChange={this.handleDropOfChange}
          googleCallbackName="initTwo"
          onSelect={this.handleDropOfSelect}
        >
          {({
            getInputProps,
            suggestions,
            getSuggestionItemProps,
            loading
          }) => (
              <div>
                <FormGroup>
                  <Label for="Dropoff"> Select Dropoff Location:</Label>
                  <Input
                    {...getInputProps({
                      className: "location-search-input"
                    })}
                  />
                  <div style={{ fontSize: 12, color: "red" }}>
                    {this.state.dropOfError}
                  </div>
                </FormGroup>
                <div className="autocomplete-dropdown-container">
                  {loading && <div>Loading...</div>}
                  {suggestions.map(suggestion => {
                    const className = suggestion.active
                      ? "suggestion-item--active"
                      : "suggestion-item";
                    // inline style for demonstration purpose
                    const style = suggestion.active
                      ? { backgroundColor: "#fafafa", cursor: "pointer" }
                      : { backgroundColor: "#ffffff", cursor: "pointer" };
                    return (
                      <div
                        {...getSuggestionItemProps(suggestion, {
                          className,
                          style
                        })}
                      >
                        <span>{suggestion.description}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
        </PlacesAutocomplete>
        Number of Seats Available:
        <Input
          value={this.state.availableSeats}
          type="number"
          name="availableSeats"
          min={0}
          onChange={e => {
            this.setState({ availableSeats: e.target.value });
          }}
        />
        <div style={{ fontSize: 12, color: "red" }}>
          {this.state.availableSeatsError}
        </div>
        <br></br>
        Enter Price:
        <Input
          value={this.state.price}
          type="number"
          name="price"
          min={0}
          onChange={e => {
            this.setState({ price: e.target.value });
          }}
        />
        <div style={{ fontSize: 12, color: "red" }}>
          {this.state.priceError}
        </div>
        <br></br>
        <Button type="submit">
          Submit
        </Button>
<br></br>
<br></br>
<h2>
Trips Request you Recieved
</h2>
{this.renderRides()}

      </Form>
    );
  }
}
