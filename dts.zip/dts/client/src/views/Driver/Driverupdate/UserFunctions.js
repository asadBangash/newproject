import axios from 'axios'

export const register = newUser => {
  return axios
    .put('drivers/updatedriver', {
      first_name: newUser.first_name,
      last_name: newUser.last_name,
      username: newUser.username,
      contact: newUser.contact,
      license_no: newUser.license_no,
      nic: newUser.nic,
      car_model: newUser.car_model,
      car_no: newUser.car_no,
      route: newUser.route,
      car_type: newUser.car_type,
      email: newUser.email,
      password: newUser.password,
      gender: newUser.gender,
      created: newUser.created
    })
    .then(response => {
      console.log('Registered')
    })
    // .catch(err => { 
    //   this.setState({errormsg: err.message});
    // })
}

export const login = driver => {
  return axios
    .post('drivers/driverlogin', {
      email: driver.email,
      password: driver.password
    })
    .then(response => {
      localStorage.setItem('usertoken', response.data)
      localStorage.setItem('loginUser', driver.email)
      return response.data
    })
    .catch(err => {
      console.log(err)
    })
}
export const notification = () => {
  const driver_email = localStorage.getItem('loginUser');
  return axios
    .post('/admins/getNotification', {
      driver_email
    })
    .then(response => {
      return response.data
    })
    .catch(err => {
      console.log(err)
    })
}

