// import React, { Component } from 'react';
// import { Alert, Card, CardBody, CardHeader, Col, Row } from 'reactstrap';

// class DriverMessages extends Component {
//   constructor(props) {
//     super(props);

//     this.state = {
//       visible: true,
//     };

//     this.onDismiss = this.onDismiss.bind(this);
//   }

//   onDismiss() {
//     this.setState({ visible: false });
//   }

//   render() {
//     return (
//       <div className="animated fadeIn">
//         <Row>
          
//           <Col xs="12" md="12">
//             <Card>
//               <CardHeader>
//                 <i className="fa fa-align-justify"></i><strong>New Messages</strong>
//                 {/* <small> use <code>.alert-link</code> to provide links</small> */}
//               </CardHeader>
//               <CardBody>
//                 <Alert color="primary">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Message</a>.From,,,,,,,,,, 
//                 </Alert>
//                 <Alert color="secondary">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Message</a>.From,,,,,,,,,, 
//                 </Alert>
//                 <Alert color="success">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Message</a>.From,,,,,,,,,, 
//                 </Alert>
//                 <Alert color="danger">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Message</a>.From,,,,,,,,,, 
//                 </Alert>
//                 <Alert color="warning">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Message</a>.From,,,,,,,,,, 
//                 </Alert>
//                 <Alert color="info">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Message</a>.From,,,,,,,,,, 
//                 </Alert>
//                 <Alert color="light">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Message</a>.From,,,,,,,,,, 
//                 </Alert>
//                 <Alert color="dark">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Message</a>.From,,,,,,,,,, 
//                 </Alert>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>
        
//       </div>
//     );
//   }
// }

// export default DriverMessages;
import React, { Component } from 'react';
import {
  Button,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  Col,
  Alert,
  Row,
} from 'reactstrap';

import Axios from 'axios';

class DriverMessages extends Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.toggleFade = this.toggleFade.bind(this);
    this.state = {
      collapse: true,
      fadeIn: true,
      timeout: 300,
      recepits: [],
    };
  }
  componentDidMount() {
    const token_jwt = localStorage.getItem('usertoken');
    Axios.post(
      '/drivers/get_recepits',
      {},
      {
        headers: {
          'x-auth-token': token_jwt,
        },
      }
    ).then((res) => {
      this.setState({ recepits: res.data });
      console.log(res);
    });
  }
  toggle() {
    this.setState({ collapse: !this.state.collapse });
  }

  toggleFade() {
    this.setState((prevState) => {
      return { fadeIn: !prevState };
    });
  }

  renderRecepits = () => {
    return this.state.recepits.map((recept) => {
      console.log(recept);
      return (
        <Alert color='primary'>
          <a target='blank' href={recept.recepit}>
            {recept.recepit}
          </a>
        </Alert>
      );
    });
  };

  render() {
    return (
      <div className='animated fadeIn'>
        <Row>
          <Col>
            <Card>
              <CardHeader>
                <strong>Payments Recepits</strong>
              </CardHeader>
              <CardBody>
                <Row>
                  <Col xs='12'>{this.renderRecepits()}</Col>
                </Row>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
    );
  }
}

export default DriverMessages;
