import React, { Component } from 'react';
import {
  Badge,
  Button,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  Col,
  Collapse,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Fade,
  Form,
  FormGroup,
  FormText,
  FormFeedback,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButtonDropdown,
  InputGroupText,
  Label,
  Row,
} from 'reactstrap';

class Forms extends Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.toggleFade = this.toggleFade.bind(this);
    this.state = {
      collapse: true,
      fadeIn: true,
      timeout: 300
    };
  }

  toggle() {
    this.setState({ collapse: !this.state.collapse });
  }

  toggleFade() {
    this.setState((prevState) => { return { fadeIn: !prevState }});
  }

  render() {
    return (
      <div className="animated fadeIn">
        
        <Row>
          <Col>
            <Card>
              <CardHeader>
                <strong>Update Profile</strong>
              </CardHeader>
              <CardBody>
                <Form action="" method="post" encType="multipart/form-data" className="form-horizontal">
                <Row>
                    <Col xs="12" sm="6">
                    <InputGroup className="mb-3">
                      <InputGroupAddon addonType="prepend">
                      </InputGroupAddon>
                      <Input type="text" placeholder="First Name" autoComplete="First Name" />
                    </InputGroup>
                    </Col>
                    
                    <Col xs="12" sm="6">
                    <InputGroup className="mb-3">
                      <InputGroupAddon addonType="prepend">
                      </InputGroupAddon>
                      <Input type="text" placeholder="Last Name" autoComplete="Last Name" />
                    </InputGroup>
                    </Col>
                    </Row>

                    <Row>
                    <Col xs="12" sm="6">
                    <InputGroup className="mb-3">
                      <InputGroupAddon addonType="prepend">
                      </InputGroupAddon>
                      <Input type="text" placeholder="Username" autoComplete="username" />
                    </InputGroup>
                    </Col>

                    <Col xs="12" sm="6">
                    <InputGroup className="mb-3">
                      <InputGroupAddon addonType="prepend">
                      </InputGroupAddon>
                      <Input type="text" placeholder="Contact" autoComplete="Contact" />
                    </InputGroup>
                    </Col>
                    </Row>

                    <Row>
                    <Col xs="12" sm="6">  
                    <InputGroup className="mb-3">
                      <InputGroupAddon addonType="prepend">
                      </InputGroupAddon>
                      <Input type="text" placeholder="License No" autoComplete="License No" />
                    </InputGroup>
                    </Col>
                    
                    <Col xs="12" sm="6"> 
                    <InputGroup className="mb-3">
                      <InputGroupAddon addonType="prepend">
                      </InputGroupAddon>
                      <Input type="text" placeholder="NIC" autoComplete="NIC" />
                    </InputGroup>
                    </Col>
                    </Row>

                    <Row>
                    <Col xs="12" sm="6"> 
                    <InputGroup className="mb-3">
                      <InputGroupAddon addonType="prepend">
                      </InputGroupAddon>
                      <Input type="text" placeholder="Car Model" autoComplete="Car Model" />
                    </InputGroup>
                    </Col>

                    <Col xs="12" sm="6"> 
                    <InputGroup className="mb-3">
                      <InputGroupAddon addonType="prepend">
                      </InputGroupAddon>
                      <Input type="text" placeholder="Car No" autoComplete="Car No" />
                    </InputGroup>
                    </Col>
                    </Row>

                    <Row>
                    <Col xs="12" sm="6"> 
                    <InputGroup className="mb-3">
                      <InputGroupAddon addonType="prepend">
                      </InputGroupAddon>
                      <Input type="text" placeholder="Route" autoComplete="Route" />
                    </InputGroup>
                    </Col> 

                    <Col xs="12" sm="6"> 
                    <InputGroup className="mb-3">
                      <InputGroupAddon addonType="prepend">
                      </InputGroupAddon>
                      <Input type="text" placeholder="Car type" autoComplete="Car type" />
                    </InputGroup>
                    </Col> 
                    </Row>
                    
                    <Row>
                    <Col xs="12" sm="6"> 
                    <InputGroup className="mb-3">
                      <InputGroupAddon addonType="prepend">
                      </InputGroupAddon>
                      <Input type="text" placeholder="Email" autoComplete="email" />
                    </InputGroup>
                    </Col>
                    
                    <Col xs="12" sm="6"> 
                    <InputGroup className="mb-3">
                      <InputGroupAddon addonType="prepend">
                      </InputGroupAddon>
                      <Input type="password" placeholder="Password" autoComplete="new-password" />
                    </InputGroup>
                    </Col>
                    </Row>

                    <Row>
                    <Col xs="12" sm="6"> 
                    <InputGroup className="mb-4">
                      <InputGroupAddon addonType="prepend">
                      </InputGroupAddon>
                      <Input type="text" placeholder="Map" autoComplete="Map" />
                    </InputGroup>
                    </Col>

                    <Col xs="12" sm="6"> 
                    <InputGroup className="mb-4">
                      <InputGroupAddon addonType="prepend">
                      </InputGroupAddon>
                      <Input type="text" placeholder="Gender" autoComplete="Gender" />
                    </InputGroup>
                    </Col>
                    </Row>
                  
                  <FormGroup row>
                    <Col md="3">
                      <Label htmlFor="file-multiple-input">Upload Image</Label>
                    </Col>
                    <Col xs="12" md="9">
                      <Input type="file" id="file-multiple-input" name="file-multiple-input" multiple />
                    </Col>
                  </FormGroup>
                  
                </Form>
              </CardBody>
              <CardFooter>
                <Button type="submit" size="sm" color="primary"><i className="fa fa-dot-circle-o"></i> Submit</Button>
                <Button type="reset" size="sm" color="danger"><i className="fa fa-ban"></i> Reset</Button>
              </CardFooter>
            </Card>
            
          </Col>
          
        </Row>
      </div>
    );
  }
}

export default Forms;
