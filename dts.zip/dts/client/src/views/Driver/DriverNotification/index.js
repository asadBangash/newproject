// import React, { Component } from 'react';
// import { Alert, Card, CardBody, CardHeader, Col, Row } from 'reactstrap';

// class DriverNotifications extends Component {
//   constructor(props) {
//     super(props);

//     this.state = {
//       visible: true,
//     };

//     this.onDismiss = this.onDismiss.bind(this);
//   }

//   onDismiss() {
//     this.setState({ visible: false });
//   }

//   render() {
//     return (
//       <div className="animated fadeIn">
//         <Row>

//           <Col xs="12" md="12">
//             <Card>
//               <CardHeader>
//                 <i className="fa fa-align-justify"></i><strong>Notifications</strong>
//                 {/* <small> use <code>.alert-link</code> to provide links</small> */}
//               </CardHeader>
//               <CardBody>
//                 <Alert color="primary">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Passenger is Registerd</a>.From,,,,,,,,,, 
//                 </Alert>
//                 <Alert color="secondary">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Passenger is Registerd</a>.From,,,,,,,,,, 
//                 </Alert>
//                 <Alert color="success">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Passenger is Registerd</a>.From,,,,,,,,,, 
//                 </Alert>
//                 <Alert color="danger">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Passenger is Registerd</a>.From,,,,,,,,,, 
//                 </Alert>
//                 <Alert color="warning">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Passenger is Registerd</a>.From,,,,,,,,,, 
//                 </Alert>
//                 <Alert color="info">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Passenger is Registerd</a>.From,,,,,,,,,, 
//                 </Alert>
//                 <Alert color="light">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Passenger is Registerd</a>.From,,,,,,,,,, 
//                 </Alert>
//                 <Alert color="dark">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Passenger registerd</a>.From,,,,,,,,,, 
//                 </Alert>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>

//       </div>
//     );
//   }
// }

// export default DriverNotifications;
import React, { Component } from 'react';
import { Link } from "react-router-dom";
import { Alert, Card, CardBody, CardHeader, Col, Row, Table, Button } from 'reactstrap';
import Axios from 'axios'
class DriverNotifications extends Component {
  constructor(props) {
    super(props);

    this.state = {
      visible: true,
      rides: [],
      // trip:[],
      rideUpdate: false
    };

    this.onDismiss = this.onDismiss.bind(this);
  }

  onDismiss() {
    this.setState({ visible: false });
  }

  getRideList = () => {
    const token = localStorage.getItem('usertoken');
    Axios.get('/drivers/driver_rides', {
      headers: {
        'x-auth-token': token
      }
    }).then(res => {
      console.log(res.data);
      this.setState({ trips: res.data })
    })

  }

  componentDidMount() {
    this.getRideList()

  }


  handleTrack = (id) => {
    window.localStorage.setItem("driverId", id);
  };

  cancelRide = (rideId) => {
    console.log(rideId);

    const token_jwt = localStorage.getItem("usertoken");
    Axios.post("/drivers/cancel_ride", { rideId }, {
      headers: {
        "x-auth-token": token_jwt,
      },
    }).then(trip => {
      this.getRideList()
    });


  }
  completeRide = (rideId) => {
    console.log(rideId);

    const token_jwt = localStorage.getItem("usertoken");
    Axios.post("/drivers/complete_ride", { rideId }, {
      headers: {
        "x-auth-token": token_jwt,
      },
    }).then(trip => {
      this.getRideList()
    });


  }

  renderRides = () => {
    if (this.state.trips) {
      return this.state.trips.map((trip) => {
        return (
          <tr>
            <td>{trip.ride_id}</td>
            <td>{trip.pickupLocation}</td>
            <td>{trip.dropoffLocation}</td>
            <td>{trip.numberOfSeats}</td>
            <td>{trip.totalPrice}</td>
            <td>{trip.passengerId}</td>
            <td>{trip.status}</td>
            <td>{trip.created}</td>
            <td>
              {" "}
              <Link to='/driver-dashboard/updatelocation'>
                <Button
                  className='btn btn-alert'
                  onClick={() => {
                    localStorage.setItem('passengerId', trip.passengerId);
                    localStorage.setItem('ride_id', trip.ride_id)
                  }}
                >
                  Track
              </Button>
              </Link>{" "}
            </td>
            <td> {trip.status === 'placed' ?
              <button
                type='button'
                onClick={() => {

                  this.cancelRide(trip.ride_id);
                  // .then(() => {
                  //   this.getRideList()
                  // })
                }} className="btn btn-danger">Cancel</button> :

              <Button disabled className="btn btn-danger">Cancel</Button>}  </td>
            <td> {trip.status === 'placed' ?
              <button
                type='button'
                onClick={() => {

                  this.completeRide(trip.ride_id);
                  // .then(() => {
                  //   this.getRideList()
                  // })
                }} className="btn btn-success">Complete</button> :

              <Button disabled className="btn btn-success">Complete</Button>}  </td>
              

          </tr>
          

        )
      })
    }
  }
  render() {
    return (
      <div className="animated fadeIn">
        <Row>

          <Col xs="12" md="12">
            <Card>
              <CardHeader>
                <i className="fa fa-align-justify"></i><strong>Trips requests</strong>
                {/* <small> use <code>.alert-link</code> to provide links</small> */}
              </CardHeader>
              <CardBody>
                <Table>

                  <th>Ride Id</th>
                  <th>PickUp Location</th>
                  <th>Dropoff Location</th>
                  <th>Number of Seats</th>
                  <th>Total Price</th>
                  <th>Passenger Id </th>
                  <th>Status</th>
                  <th>Date/Time</th>
                  <th>Location</th>
                  <th>Action</th>
                  <th>End</th>
                  
                  {this.renderRides()}
                </Table>
              </CardBody>
            </Card>
          </Col>
        </Row>

      </div>
    );
  }
}

export default DriverNotifications;
