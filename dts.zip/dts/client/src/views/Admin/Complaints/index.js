// import React, { Component } from 'react';
// import { Alert, Card, CardBody, CardHeader, Col, Row } from 'reactstrap';

// class Complaints extends Component {
//   constructor(props) {
//     super(props);

//     this.state = {
//       visible: true,
//     };

//     this.onDismiss = this.onDismiss.bind(this);
//   }

//   onDismiss() {
//     this.setState({ visible: false });
//   }

//   render() {
//     return (
//       <div className="animated fadeIn">
//         <Row>
          
//           <Col xs="12" md="12">
//             <Card>
//               <CardHeader>
//                 <i className="fa fa-align-justify"></i><strong>Complaints</strong>
//                 {/* <small> use <code>.alert-link</code> to provide links</small> */}
//               </CardHeader>
//               <CardBody>
//                 <Alert color="primary">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Complaint</a>.From Peshawar 
//                 </Alert>
//                 <Alert color="secondary">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Complaint</a>.From Peshawar 
//                 </Alert>
//                 <Alert color="success">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Complaint</a>.From User 
//                 </Alert>
//                 <Alert color="danger">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Complaint</a>.From User 
//                 </Alert>
//                 <Alert color="warning">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Complaint</a>.From User 
//                 </Alert>
//                 <Alert color="info">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Complaint</a>.From User 
//                 </Alert>
//                 <Alert color="light">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Complaint</a>.From User 
//                 </Alert>
//                 <Alert color="dark">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Complaint</a>.From User 
//                 </Alert>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>
        
//       </div>
//     );
//   }
// }

// export default Complaints;


import React, { Component } from 'react';
import { Badge, Card, CardBody, CardHeader, Col, Pagination, PaginationItem, PaginationLink, Row, Table } from 'reactstrap';

class Complaints extends Component {
  render() {
    return (
      <div className="animated fadeIn">
        <Row>
          

          <Col>
            <Card>
              <CardHeader>
                <i className="fa fa-align-justify"></i> Complaints
              </CardHeader>
              <CardBody>
                <Table responsive striped>
                  <thead>
                  <tr>
                    <th>Complaint title</th>
                    <th>Date</th>
                    
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td><a href="#">Complaint from user.....</a></td>
                    <td>2012/01/01</td>
                    
                    <td>
                      <a href="#">Approve</a>||<a href="#">Decline</a>
                    </td>
                  </tr>
                  <tr>
                  <td><a href="#">Complaint from user.....</a></td>
                    <td>2012/02/01</td>
                    
                    <td>
                    <a href="#">Approve</a>||<a href="#">Decline</a>
                    </td>
                  </tr>
                  <tr>
                  <td><a href="#">Complaint from user.....</a></td>
                    <td>2012/02/01</td>
                    
                    <td>
                    <a href="#">Approve</a>||<a href="#">Decline</a>
                    </td>
                  </tr>
                  <tr>
                  <td><a href="#">Complaint from user.....</a></td>
                    <td>2012/03/01</td>
                    
                    <td>
                    <a href="#">Approve</a>||<a href="#">Decline</a>
                    </td>
                  </tr>
                  <tr>
                  <td><a href="#">Complaint from user.....</a></td>
                    <td>2012/01/21</td>
                    
                    <td>
                    <a href="#">Approve</a>||<a href="#">Decline</a>
                    </td>
                  </tr>
                  </tbody>
                </Table>
                <Pagination>
                  <PaginationItem disabled><PaginationLink previous tag="button">Prev</PaginationLink></PaginationItem>
                  <PaginationItem active>
                    <PaginationLink tag="button">1</PaginationLink>
                  </PaginationItem>
                  <PaginationItem><PaginationLink tag="button">2</PaginationLink></PaginationItem>
                  <PaginationItem><PaginationLink tag="button">3</PaginationLink></PaginationItem>
                  <PaginationItem><PaginationLink tag="button">4</PaginationLink></PaginationItem>
                  <PaginationItem><PaginationLink next tag="button">Next</PaginationLink></PaginationItem>
                </Pagination>
              </CardBody>
            </Card>
          </Col>
        

        
        </Row>
      </div>

    );
  }
}

export default Complaints;
