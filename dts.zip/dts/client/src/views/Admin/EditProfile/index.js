import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import {
  Button,
  Card,
  CardBody,
  CardFooter,
  Col,
  Container,
  Form,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Row,
} from 'reactstrap';
import axios from 'axios';
class Edit_Profile extends Component {
  constructor() {
    super();
    this.state = {
      user: null,
      first_name: '',
      last_name: '',
      username: '',

      email: '',
      password: '',

      created: '',
      errors: {},
      message: null,
    };
  }

  componentDidMount() {
    const token = localStorage.getItem('usertoken');
    axios
      .get('http://localhost:5000/admins/admin_info', {
        headers: {
          'x-auth-token': token,
        },
      })
      .then((user) => {
        console.log(user);
        this.setState({
          first_name: user.data.admin.first_name,
          last_name: user.data.admin.last_name,
          username: user.data.admin.username,
          email: user.data.admin.email,
        });
      });
  }
  onChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  validate = () => {
    let first_nameError = '';
    let last_nameError = '';
    let usernameError = '';

    let emailError = '';
    let passwordError = '';

    // if(!this.state.email.includes('@')){
    //   emailError = 'invalid email';
    // }
    if (!this.state.first_name) {
      first_nameError = 'please type first name';
    }
    if (!this.state.last_name) {
      last_nameError = 'please type last name';
    }
    if (!this.state.username) {
      usernameError = 'please type username';
    }

    if (!this.state.email) {
      emailError = 'please type email';
    }

    if (first_nameError || last_nameError || usernameError || emailError) {
      this.setState({
        first_nameError,
        last_nameError,
        usernameError,
        emailError,
      });
      return false;
    }
    return true;
  };

  onSubmit = (e) => {
    e.preventDefault();
    const isValid = this.validate();
    const newUser = {
      first_name: this.state.first_name,
      last_name: this.state.last_name,
      username: this.state.username,
      email: this.state.email,
      password: this.state.password
    };
    console.log("MATCH=");
    console.log(this.props.match);
    newUser.id = localStorage.getItem('adminId');
    // alert(newUser.id);
    console.log(newUser);
    // if (isValid) {
    const token = localStorage.getItem('usertoken');
    axios
      .put(
        `http://localhost:5000/admins/edit_profile/${newUser.id}`,
        { newUser },
        {
          headers: {
            'x-auth-token': token,
          },
        }
      )
      .then((user) => {
        console.log(user);
        this.setState({ message: user.data.message });
      });
    // }
  };

  render() {
    console.log(this.state.user);
    return (
      <div className='animated fadeIn'>
        <Container className='section'>
          <Row className='justify-content-center'>
            <Col md='9' lg='7' xl='6'>
              <Card className='mx-4'>
                <CardBody className='p-4'>
                  <Form onSubmit={this.onSubmit}>
                    <h1>Edit Your Profile</h1>

                    <Row>
                      <Col xs='12' sm='6'>
                        <InputGroup className='mb-3'>
                          <InputGroupAddon addonType='prepend'></InputGroupAddon>
                          <Input
                            type='text'
                            placeholder='First Name'
                            name='first_name'
                            value={this.state.first_name}
                            onChange={this.onChange}
                            defaultValue='Hello'
                          />
                        </InputGroup>
                        <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.first_nameError}
                        </div>
                      </Col>

                      <Col xs='12' sm='6'>
                        <InputGroup className='mb-3'>
                          <InputGroupAddon addonType='prepend'></InputGroupAddon>
                          <Input
                            type='text'
                            placeholder='Last Name'
                            name='last_name'
                            value={this.state.last_name}
                            onChange={this.onChange}
                          />
                        </InputGroup>
                        <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.last_nameError}
                        </div>
                      </Col>
                    </Row>

                    <Row>
                      <Col xs='12' sm='6'>
                        <InputGroup className='mb-3'>
                          <InputGroupAddon addonType='prepend'></InputGroupAddon>
                          <Input
                            type='text'
                            placeholder='Username'
                            name='username'
                            value={this.state.username}
                            onChange={this.onChange}
                          />
                        </InputGroup>
                        <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.usernameError}
                        </div>
                      </Col>
                      <Col xs='12' sm='6'>
                        <InputGroup className='mb-3'>
                          <InputGroupAddon addonType='prepend'></InputGroupAddon>
                          <Input
                            type='password'
                            placeholder='Password'
                            name='password'
                            value={this.state.password}
                            onChange={this.onChange}
                            
                          />
                        </InputGroup>
                        {/* <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.usernameError}
                        </div> */}
                      </Col>
                    </Row>

                    <Row>
                      <Col xs='12' sm='6'>
                        <InputGroup className='mb-3'>
                          <InputGroupAddon addonType='prepend'></InputGroupAddon>
                          <Input
                            type='email'
                            placeholder='Email'
                            name='email'
                            value={this.state.email}
                            onChange={this.onChange}
                          />
                        </InputGroup>
                        <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.emailError}
                        </div>
                      </Col>
                    </Row>

                    <Button type='submit' color='success' block>
                      Edit Profile
                    </Button>
                  </Form>

                  {this.state.message !== null ? (
                    <h4>{this.state.message}</h4>
                  ) : null}
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }
}

export default Edit_Profile;
