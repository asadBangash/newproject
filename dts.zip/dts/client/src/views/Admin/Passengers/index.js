// import React, { Component } from 'react';
// import { Badge, Card, CardBody, CardHeader, Col, Pagination, PaginationItem, PaginationLink, Row, Table } from 'reactstrap';

// class Passengers extends Component {
//   render() {
//     return (
//       <div className="animated fadeIn">
//         <Row>


//           <Col>
//             <Card>
//               <CardHeader>
//                 <i className="fa fa-align-justify"></i> Passengers
//               </CardHeader>
//               <CardBody>
//                 <Table responsive striped>
//                   <thead>
//                   <tr>
//                     <th>S.No</th>
//                     <th>Username</th>
//                     <th>Location</th>
//                     <th>Contact</th>
//                     <th>Status</th>

//                     <th>Action</th>
//                   </tr>
//                   </thead>
//                   <tbody>
//                   <tr>
//                     <td>01</td>
//                     <td>M Omar</td>
//                     <td>Peshawar</td>

//                     <td>03339666555</td>
//                     <td>
//                       <Badge color="success">Active</Badge>
//                     </td>
//                     <td><a href="">Warn</a>||<a href="">Delete</a></td>
//                   </tr>
//                   <tr>
//                     <td>02</td>
//                     <td>Saqib</td>
//                     <td>Saddar</td>

//                     <td>03339666555</td>
//                     <td>
//                       <Badge color="danger">Banned</Badge>
//                     </td>
//                     <td><a href="">Warn</a>||<a href="">Delete</a></td>
//                   </tr>
//                   <tr>
//                     <td>03</td>
//                     <td>Javed</td>
//                     <td>Board</td>

//                     <td>03339666555</td>
//                     <td>
//                       <Badge color="secondary">Inactive</Badge>
//                     </td>
//                     <td><a href="">Warn</a>||<a href="">Delete</a></td>
//                   </tr>
//                   <tr>
//                     <td>04</td>
//                     <td>Asad</td>
//                     <td>RingRoad</td>

//                     <td>03339666555</td>
//                     <td>
//                       <Badge color="warning">Pending</Badge>
//                     </td>
//                     <td><a href="">Warn</a>||<a href="">Delete</a></td>
//                   </tr>
//                   <tr>
//                   <td>05</td>
//                     <td>kamran</td>
//                     <td>Hayatabad</td>

//                     <td>03339666555</td>
//                     <td>
//                       <Badge color="success">Active</Badge>
//                     </td>
//                     <td><a href="">Warn</a>||<a href="">Delete</a></td>
//                   </tr>
//                   </tbody>
//                 </Table>
//                 <Pagination>
//                   <PaginationItem disabled><PaginationLink previous tag="button">Prev</PaginationLink></PaginationItem>
//                   <PaginationItem active>
//                     <PaginationLink tag="button">1</PaginationLink>
//                   </PaginationItem>
//                   <PaginationItem><PaginationLink tag="button">2</PaginationLink></PaginationItem>
//                   <PaginationItem><PaginationLink tag="button">3</PaginationLink></PaginationItem>
//                   <PaginationItem><PaginationLink tag="button">4</PaginationLink></PaginationItem>
//                   <PaginationItem><PaginationLink next tag="button">Next</PaginationLink></PaginationItem>
//                 </Pagination>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>



//       </div>

//     );
//   }
// }

// export default Passengers;
// import React, { Component } from 'react';
// import { Alert, Card, CardBody, CardHeader, Col, Row } from 'reactstrap';

// class PassengerMessages extends Component {
//   constructor(props) {
//     super(props);

//     this.state = {
//       visible: true,
//     };

//     this.onDismiss = this.onDismiss.bind(this);
//   }

//   onDismiss() {
//     this.setState({ visible: false });
//   }

//   render() {
//     return (
//       <div className="animated fadeIn">
//         <Row>

//           <Col xs="12" md="12">
//             <Card>
//               <CardHeader>
//                 <i className="fa fa-align-justify"></i><strong>New Messages</strong>
//                 {/* <small> use <code>.alert-link</code> to provide links</small> */}
//               </CardHeader>
//               <CardBody>
//                 <Alert color="primary">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Message</a>.From,,,,,,,,, 
//                 </Alert>
//                 <Alert color="secondary">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Message</a>.From,,,,,,,,, 
//                 </Alert>
//                 <Alert color="success">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Message</a>.From,,,,,,,,, 
//                 </Alert>
//                 <Alert color="danger">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Message</a>.From,,,,,,,,, 
//                 </Alert>
//                 <Alert color="warning">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Message</a>.From,,,,,,,,, 
//                 </Alert>
//                 <Alert color="info">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Message</a>.From,,,,,,,,, 
//                 </Alert>
//                 <Alert color="light">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Message</a>.From,,,,,,,,, 
//                 </Alert>
//                 <Alert color="dark">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Message</a>.From,,,,,,,,, 
//                 </Alert>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>

//       </div>
//     );
//   }
// }




// import React, { Component } from 'react';
// import GoogleMap from 'google-map-react';

// const mapStyles = {
//   width: '100%',
//   height: '100%'
// }

// const markerStyle = {
//   height: '50px',
//   width: '50px',
//   marginTop: '-50px'
// }

// const imgStyle = {
//   height: '100%'
// }


// const Marker = ({ title }) => (
//   <div style={markerStyle}>
//     <img style={imgStyle} src="https://res.cloudinary.com/og-tech/image/upload/s--OpSJXuvZ--/v1545236805/map-marker_hfipes.png" alt={title} />
//     <h3>{title}</h3>
//   </div>
// );

// class PassengerMessages extends Component {
//   render() {
//     return (
//       <div >
//         <GoogleMap
//           style={mapStyles}
//           bootstrapURLKeys={{ key: 'AIzaSyD7B6pgMojzFAr8PNVALNecGA1GpRfyhqA' }}
//           center={{ lat: 5.6219868, lng: -0.1733074 }}
//           zoom={14}
//         >
//           <Marker
//           title={'Current Location'}
//           lat={5.6219868}
//           lng={-0.1733074}
//         >
//           </Marker>
//         </GoogleMap>
//       </div>
//     )
//   }
// }

// export default PassengerMessages;


import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { Alert, Card, CardBody, CardHeader, Col, Row, Table, Button } from 'reactstrap';
import Axios from 'axios'
class Passengers extends Component {
  constructor(props) {
    super(props);

    this.state = {
      visible: true,
      passengers: [],
      passengersUpdate: false
    };

    this.onDismiss = this.onDismiss.bind(this);
  }

  onDismiss() {
    this.setState({ visible: false });
  }

  getPassengerList = () => {

    Axios.get("/admins/get_passengers", {

    }).then((res) => this.setState({ passengers: res.data }));      //.then((res) => console.log(res));

  }

  componentDidMount() {
    this.getPassengerList()

  }

  renderPassengers = () => {
    return this.state.passengers.map((passenger) => {
      console.log(passenger)
      return (
        <tr>
          <td>{passenger.passenger_id}</td>
          <td>{passenger.username}</td>
          <td>{passenger.contact}</td>
          {/* <td>{passenger.car_model}</td>
          <td>{passenger.car_no}</td> */}
          {/* <td>{ride.status}</td>*/}
          <td> <Link to="/admin-dashboard/location">
            <Button className="btn btn-alert" onClick={() => {
              localStorage.setItem('passengerId', passenger.passenger_id);
              localStorage.setItem('IsDriver', 'false');
            }}>Track</Button></Link>  </td>
        </tr>
      )
    })
  }
  render() {
    return (
      <div className="animated fadeIn">
        <Row>

          <Col xs="12" md="12">
            <Card>
              <CardHeader>
                <i className="fa fa-align-justify"></i><strong>All Passengers</strong>
                {/* <small> use <code>.alert-link</code> to provide links</small> */}
              </CardHeader>
              <CardBody>
                <Table>

                  <th>Passenger Id</th>
                  <th>Name</th>
                  <th>Contact</th>

                  {/* <th>Status</th>*/}
                  <th>Location</th>
                  {this.renderPassengers()}
                </Table>
              </CardBody>
            </Card>
          </Col>
        </Row>

      </div>
    );
  }
}

export default Passengers;


