import React from 'react';
import Axios from 'axios';
import Payment from './Payment';
import { Link } from 'react-router-dom';
import PlacesAutocomplete, {
  geocodeByAddress,
  getLatLng,
} from 'react-places-autocomplete';
import {
  Button,
  Form,
  FormGroup,
  Label,
  Input,
  FormText,
  Table,
  Container,
  Col,
  Row,
  Alert,
} from 'reactstrap';
export default class StarttDrive extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      pickUp: '',
      token: null,
      ride_info: null,
      dropOf: '',
      availableSeats: 0,
      price: 0,
      driver: [],
      selectedDriver: null,
      message: null,
      created: '',
      check: 0,
    };
  }

  handleChange = (pickUp) => {
    this.setState({ pickUp });
  };
  handleDropOfChange = (dropOf) => {
    this.setState({ dropOf });
    const data = { pickUp: this.state.pickUp, dropOff: this.state.dropOf };
    Axios.post('/passengers/driver_search', data).then((res) => {
      console.log(this.state.driver);
      this.setState({ driver: res.data });
    });
  };
  SubmitData = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (this.state.token !== null) {
      let data = {
        pickupLocation: this.state.pickUp,
        dropoffLocation: this.state.dropOf,
        numberOfSeats: this.state.availableSeats,
        driverId: this.state.selectedDriver,
        token: this.state.token,
        // created: this.state.created,
      };
      const token_jwt = localStorage.getItem('usertoken');

      if (this.state.selectedDriver === null && this.state.check !== 0) {
        alert('Please Select the Driver to Start Ride..!');
      } else {
        Axios.post('/passengers/new_ride', data, {
          headers: {
            'x-auth-token': token_jwt,
          },
        }).then((res) => this.setState({ message: res.data.status }));
      }
    }
  };
  getDriverRide = (driver_id) => {
    console.log(driver_id);
    let data = {
      pickupLocation: this.state.pickUp,
      dropoffLocation: this.state.dropOf,
      driverId: driver_id,
    };
    Axios.post('/startrides/getDriverRide', data).then((res) => {
      this.setState({ ride_info: res.data });
    });
    this.setState({ selectedDriver: driver_id });
  };
  handleSelect = (pickUp) => {
    geocodeByAddress(pickUp)
      .then((results) => getLatLng(results[0]))
      .then((latLng) => console.log('Success', latLng))
      .catch((error) => console.error('Error', error));
  };

  confirmPayment = (token) => {
    this.setState({ token: token.id, check: 1 });
    console.log(token);
    console.log(this.state.token);
  };
  setRoom(driverEmail) {
    localStorage.setItem('msgReceiver', driverEmail);
    localStorage.setItem(
      'room',
      `${localStorage.getItem('msgReceiver')}-chat-${localStorage.getItem(
        'loginUser'
      )}`
    );
  }

  renderDrivers = () => {
    if (this.state.selectedDriver === null) {
      return this.state.driver.map((driver) => {
        return (
          <Container>
            <Row>
              <Col md='8'>
                <Table>
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>First Name</th>
                      <th>Contact</th>
                      <th>License Number</th>
                      <th>NIC</th>
                      <th>Car Model</th>
                      <th>Car Number</th>
                      <th>Route</th>
                      <th>Car Type</th>
                      <th>Email</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <th scope='row'>1</th>
                      <td>{driver.first_name}</td>
                      <td>{driver.contact}</td>
                      <td>{driver.license_no}</td>
                      <td>{driver.nic}</td>
                      <td>{driver.car_model}</td>
                      <td>{driver.car_no}</td>
                      <td>{driver.route}</td>
                      <td>{driver.car_type}</td>
                      <td>{driver.email}</td>
                      <td>
                        <Button
                          color='success'
                          onClick={() => this.getDriverRide(driver.driver_id)}
                        >
                          Conform Driver
                        </Button>
                      </td>
                      <td>
                        <Link
                          className='btn btn-warning'
                          to={`/passenger-dashboard/chat/${driver.email}`}
                          onClick={this.setRoom(driver.email)}
                        >
                          Send Message
                        </Link>
                      </td>
                    </tr>
                  </tbody>
                </Table>
              </Col>
            </Row>
          </Container>
        );
      });
    } else {
      return null;
    }
  };

  renderideinfo = () => {
    if (this.state.ride_info !== null) {
      return (
        <Container>
          <Row>
            <Col md='8'>
              <h1>Your Ride Information</h1>
              <Table>
                <thead>
                  <tr>
                    <th>Pickup Location </th>
                    <th>Drop Off Location</th>
                    <th>Price per Ticket</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>{this.state.ride_info.select_pickup_location}</td>
                    <td>{this.state.ride_info.select_dropoff_location}</td>
                    <td>{this.state.ride_info.enter_price}</td>
                  </tr>
                </tbody>
              </Table>
            </Col>
          </Row>
        </Container>
      );
    } else {
      return null;
    }
  };

  renderInputs = () => {
    if (this.state.driver.length !== 0 && this.state.ride_info !== null) {
      return (
        <div>
          <label>Enter Number of Tickets</label>
          <Input
            value={this.state.availableSeats}
            type='number'
            name='availableSeats'
            min={0}
            onChange={(e) => {
              this.setState({ availableSeats: e.target.value });
            }}
          />
          <br></br>
          {this.state.token === null ? (
            <Payment
              price={
                this.state.ride_info.enter_price *
                this.state.availableSeats *
                100
              }
              confirmPayment={this.confirmPayment}
            />
          ) : null}

          {this.state.token !== null && this.state.check !== 0 ? (
            <Button type='submit'>Submit</Button>
          ) : null}
        </div>
      );
    } else {
      return null;
    }
  };

  handleDropOfSelect = (dropOf) => {
    geocodeByAddress(dropOf)
      .then((results) => getLatLng(results[0]))
      .then((latLng) => console.log('Success', latLng))
      .catch((error) => console.error('Error', error));
  };
  render() {
    return (
      <Form onSubmit={this.SubmitData}>
        <PlacesAutocomplete
          value={this.state.pickUp}
          onChange={this.handleChange}
          onSelect={this.handleSelect}
          googleCallbackName='initOne'
        >
          {({
            getInputProps,
            suggestions,
            getSuggestionItemProps,
            loading,
          }) => (
            <div>
              <FormGroup>
                <Label for='Pickup'>Select Pickup Location:</Label>
                <Input
                  {...getInputProps({
                    placeholder: '',
                    className: 'location-search-input',
                  })}
                />
              </FormGroup>
              <div className='autocomplete-dropdown-container'>
                {loading && <div>Loading...</div>}
                {suggestions.map((suggestion) => {
                  const className = suggestion.active
                    ? 'suggestion-item--active'
                    : 'suggestion-item';
                  // inline style for demonstration purpose
                  const style = suggestion.active
                    ? { backgroundColor: '#fafafa', cursor: 'pointer' }
                    : { backgroundColor: '#ffffff', cursor: 'pointer' };
                  return (
                    <div
                      {...getSuggestionItemProps(suggestion, {
                        className,
                        style,
                      })}
                    >
                      <span>{suggestion.description}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </PlacesAutocomplete>
        <PlacesAutocomplete
          value={this.state.dropOf}
          onChange={this.handleDropOfChange}
          googleCallbackName='initTwo'
          onSelect={this.handleDropOfSelect}
        >
          {({
            getInputProps,
            suggestions,
            getSuggestionItemProps,
            loading,
          }) => (
            <div>
              <FormGroup>
                <Label for='Dropoff'> Select Dropoff Location:</Label>
                <Input
                  {...getInputProps({
                    className: 'location-search-input',
                  })}
                />
              </FormGroup>
              <div className='autocomplete-dropdown-container'>
                {loading && <div>Loading...</div>}
                {suggestions.map((suggestion) => {
                  const className = suggestion.active
                    ? 'suggestion-item--active'
                    : 'suggestion-item';
                  // inline style for demonstration purpose
                  const style = suggestion.active
                    ? { backgroundColor: '#fafafa', cursor: 'pointer' }
                    : { backgroundColor: '#ffffff', cursor: 'pointer' };
                  return (
                    <div
                      {...getSuggestionItemProps(suggestion, {
                        className,
                        style,
                      })}
                    >
                      <span>{suggestion.description}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </PlacesAutocomplete>
        {this.renderDrivers()}
        {this.renderideinfo()}
        {this.renderInputs()}

        {this.state.message !== null ? (
          <div>
            <Alert color='primary'>{this.state.message}</Alert>
          </div>
        ) : null}
      </Form>
    );
  }
}
