import React, { Component } from 'react';
import StripeCheckout from 'react-stripe-checkout';
export default class Payment extends Component {
  render() {
    return (
      <StripeCheckout
        amount={this.props.price}
        token={(token) => {
          this.props.confirmPayment(token);
        }}
        stripeKey={process.env.REACT_APP_STRIPE_PUBLISHABLE_KEY}
        name='DTS'
        description='Pay to Confirm Your Ticket.'
        triggerEvent='onClick'
      />
    );
  }
}
