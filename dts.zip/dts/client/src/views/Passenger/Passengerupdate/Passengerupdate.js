import React, { Component } from 'react';
import {
  Button,
  Card,
  CardBody,
  CardFooter,
  Col,
  Container,
  Form,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Row,
} from 'reactstrap';
// import './style.css';
// import logo from './logo.png';
import { register } from './UserFunctions';
import axios from 'axios';

// console.log(logo);

class Passengerupdate extends Component {
  constructor() {
    super();
    this.state = {
      first_name: '',
      last_name: '',
      username: '',
      contact: '',

      route: '',

      email: '',
      password: '',
      gender: '',
      created: '',
      errormsg: '',

      errors: {},
    };

    this.onChange = this.onChange.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
  }

  componentDidMount() {
    const token = localStorage.getItem('usertoken');
    axios
      .get('http://localhost:5000/passengers/passenger-dashboard', {
        headers: {
          'authorization': token
        },
      })
      .then((user) => {
        console.log(user);
        localStorage.setItem("LoggedInUser", user.data.passenger_id);
        this.setState({
          first_name: user.data.first_name,
          last_name: user.data.last_name,
          username: user.data.username,
          contact: user.data.contact,

          route: user.data.route,

          email: user.data.email,
          gender: user.data.gender,
        });
      });
  }

  onChange(e) {
    this.setState({ [e.target.name]: e.target.value });
  }
  validate = () => {
    let first_nameError = '';
    let last_nameError = '';
    let usernameError = '';
    let contactError = '';

    let routeError = '';

    let emailError = '';
    let passwordError = '';
    let genderError = '';

    if (!this.state.first_name) {
      first_nameError = 'please type first name';
    }
    if (!this.state.last_name) {
      last_nameError = 'please type last name';
    }
    if (!this.state.username) {
      usernameError = 'please type username';
    }
    if (!this.state.contact) {
      contactError = 'please type contact';
    }

    if (!this.state.route) {
      routeError = 'please type route';
    }


    if (!this.state.email.includes('@')) {
      emailError = 'invalid email';
    }

    if (!this.state.password) {
      passwordError = 'please type password';
    }

    if (!this.state.gender) {
      genderError = 'please type gender';
    }

    if (
      first_nameError ||
      last_nameError ||
      usernameError ||
      contactError ||

      routeError ||

      emailError ||
      passwordError ||
      genderError
    ) {
      this.setState({
        first_nameError,
        last_nameError,
        usernameError,
        contactError,

        routeError,

        emailError,
        passwordError,
        genderError,
      });
      return false;
    }
    return true;
  };

  onSubmit(e) {
    e.preventDefault();
    const isValid = this.validate();
    const newUser = {
      first_name: this.state.first_name,
      last_name: this.state.last_name,
      username: this.state.username,
      contact: this.state.contact,

      route: this.state.route,

      email: this.state.email,
      password: this.state.password,
      gender: this.state.gender,
      created: this.state.created,
      id: localStorage.getItem('LoggedInUser')
    };
    if (isValid) {
      const token = localStorage.getItem('usertoken');

      axios
        .post('http://localhost:5000/passengers/edit_profile', { newUser }, {
          headers: {
            authorization: token,
          },
        })
        .then((user) => {
          this.setState({ message: user.data.message });
        });
    }
  }
  render() {
    return (
      <div className='align-items-center'>
        <Container className='section'>
          <Row className='justify-content-center'>
            <Col md='9' lg='7' xl='6'>
              <Card className='mx-4'>
                <CardBody className='p-4'>
                  <Form onSubmit={this.onSubmit}>
                    <h1>Update Profile</h1>

                    <Row>
                      <Col xs='12' sm='6'>
                        <InputGroup className='mb-3'>
                          <InputGroupAddon addonType='prepend'></InputGroupAddon>
                          <Input
                            type='text'
                            placeholder='First Name'
                            name='first_name'
                            value={this.state.first_name}
                            onChange={this.onChange}
                          />
                        </InputGroup>
                        <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.first_nameError}
                        </div>
                      </Col>

                      <Col xs='12' sm='6'>
                        <InputGroup className='mb-3'>
                          <InputGroupAddon addonType='prepend'></InputGroupAddon>
                          <Input
                            type='text'
                            placeholder='Last Name'
                            name='last_name'
                            value={this.state.last_name}
                            onChange={this.onChange}
                          />
                        </InputGroup>
                        <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.last_nameError}
                        </div>
                      </Col>
                    </Row>

                    <Row>
                      <Col xs='12' sm='6'>
                        <InputGroup className='mb-3'>
                          <InputGroupAddon addonType='prepend'></InputGroupAddon>
                          <Input
                            type='text'
                            placeholder='Username'
                            name='username'
                            value={this.state.username}
                            onChange={this.onChange}
                          />
                        </InputGroup>
                        <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.usernameError}
                        </div>
                      </Col>

                      <Col xs='12' sm='6'>
                        <InputGroup className='mb-3'>
                          <InputGroupAddon addonType='prepend'></InputGroupAddon>
                          <Input
                            type='text'
                            placeholder='Contact'
                            name='contact'
                            value={this.state.contact}
                            onChange={this.onChange}
                          />
                        </InputGroup>
                        <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.contactError}
                        </div>
                      </Col>
                    </Row>



                    <Row>
                      <Col xs='12' sm='6'>
                        <InputGroup className='mb-3'>
                          <InputGroupAddon addonType='prepend'></InputGroupAddon>
                          <Input
                            type='text'
                            placeholder='Route'
                            name='route'
                            value={this.state.route}
                            onChange={this.onChange}
                          />
                        </InputGroup>
                        <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.routeError}
                        </div>
                      </Col>


                    </Row>

                    <Row>
                      <Col xs='12' sm='6'>
                        <InputGroup className='mb-3'>
                          <InputGroupAddon addonType='prepend'></InputGroupAddon>
                          <Input
                            type='email'
                            placeholder='Email'
                            name='email'
                            value={this.state.email}
                            onChange={this.onChange}
                          />
                        </InputGroup>
                        <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.emailError}
                        </div>
                      </Col>

                      <Col xs='12' sm='6'>
                        <InputGroup className='mb-3'>
                          <InputGroupAddon addonType='prepend'></InputGroupAddon>
                          <Input
                            type='password'
                            placeholder='Password'
                            name='password'
                            value={this.state.password}
                            onChange={this.onChange}
                          
                          />
                        </InputGroup>
                        <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.passwordError}
                        </div>
                      </Col>
                    </Row>

                    <Row>
                      {/* <Col xs="12" sm="6"> 
                    <InputGroup className="mb-4">
                      <InputGroupAddon addonType="prepend">
                      </InputGroupAddon>
                      <Input type="text" placeholder="Map" autoComplete="Map" />
                    </InputGroup>
                    </Col> */}

                      <Col xs='12' sm='6'>
                        <InputGroupAddon addonType='prepend'></InputGroupAddon>
                        {/* <Input type="text" 
                      placeholder="Gender" 
                      name="gender"
                      value={this.state.gender}
                      onChange={this.onChange}
                      /> */}
                        <Input
                          type='select'
                          name='gender'
                          id='exampleSelect'
                          value={this.state.gender}
                          onChange={this.onChange}
                        >
                          <option>Select</option>
                          <option>Male</option>
                          <option>Female</option>
                        </Input>

                        <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.genderError}
                        </div>
                      </Col>
                    </Row>

                    <Button type='submit' color='success' block>
                      Update  Profile
                    </Button>
                  </Form>
                  {this.state.message !== null ? (
                    <h4>{this.state.message}</h4>
                  ) : null}
                </CardBody>

                {/* <CardFooter className="p-4">
                  <Row>
                    <Col xs="12" sm="6">
                      <Button className="btn-facebook mb-1" block><span>facebook</span></Button>
                    </Col>
                    <Col xs="12" sm="6">
                      <Button className="btn-twitter mb-1" block><span>twitter</span></Button>
                    </Col>
                  </Row>
                </CardFooter> */}
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }
}

export default Passengerupdate;
