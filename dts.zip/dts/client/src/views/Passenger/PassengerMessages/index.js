// import React, { Component } from 'react';
// import { Alert, Card, CardBody, CardHeader, Col, Row } from 'reactstrap';

// class PassengerMessages extends Component {
//   constructor(props) {
//     super(props);

//     this.state = {
//       visible: true,
//     };

//     this.onDismiss = this.onDismiss.bind(this);
//   }

//   onDismiss() {
//     this.setState({ visible: false });
//   }

//   render() {
//     return (
//       <div className="animated fadeIn">
//         <Row>

//           <Col xs="12" md="12">
//             <Card>
//               <CardHeader>
//                 <i className="fa fa-align-justify"></i><strong>New Messages</strong>
//                 {/* <small> use <code>.alert-link</code> to provide links</small> */}
//               </CardHeader>
//               <CardBody>
//                 <Alert color="primary">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Message</a>.From,,,,,,,,,
//                 </Alert>
//                 <Alert color="secondary">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Message</a>.From,,,,,,,,,
//                 </Alert>
//                 <Alert color="success">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Message</a>.From,,,,,,,,,
//                 </Alert>
//                 <Alert color="danger">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Message</a>.From,,,,,,,,,
//                 </Alert>
//                 <Alert color="warning">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Message</a>.From,,,,,,,,,
//                 </Alert>
//                 <Alert color="info">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Message</a>.From,,,,,,,,,
//                 </Alert>
//                 <Alert color="light">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Message</a>.From,,,,,,,,,
//                 </Alert>
//                 <Alert color="dark">
//                   {/*eslint-disable-next-line*/}
//                   <a href="#" className="alert-link">New Message</a>.From,,,,,,,,,
//                 </Alert>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>

//       </div>
//     );
//   }
// }

// import React, { Component } from 'react';
// import GoogleMap from 'google-map-react';

// const mapStyles = {
//   width: '100%',
//   height: '100%'
// }

// const markerStyle = {
//   height: '50px',
//   width: '50px',
//   marginTop: '-50px'
// }

// const imgStyle = {
//   height: '100%'
// }

// const Marker = ({ title }) => (
//   <div style={markerStyle}>
//     <img style={imgStyle} src="https://res.cloudinary.com/og-tech/image/upload/s--OpSJXuvZ--/v1545236805/map-marker_hfipes.png" alt={title} />
//     <h3>{title}</h3>
//   </div>
// );

// class PassengerMessages extends Component {
//   render() {
//     return (
//       <div >
//         <GoogleMap
//           style={mapStyles}
//           bootstrapURLKeys={{ key: 'AIzaSyD7B6pgMojzFAr8PNVALNecGA1GpRfyhqA' }}
//           center={{ lat: 5.6219868, lng: -0.1733074 }}
//           zoom={14}
//         >
//           <Marker
//           title={'Current Location'}
//           lat={5.6219868}
//           lng={-0.1733074}
//         >
//           </Marker>
//         </GoogleMap>
//       </div>
//     )
//   }
// }

// export default PassengerMessages;

import React, { Component } from "react";
import { Link } from "react-router-dom";
import {
  Alert,
  Card,
  CardBody,
  CardHeader,
  Col,
  Row,
  Table,
  Button,
} from "reactstrap";
import Axios from "axios";
class PassengerMessages extends Component {
  constructor(props) {
    super(props);

    this.state = {
      visible: true,
      drivers: [],
      driverUpdate: false,
    };

    this.onDismiss = this.onDismiss.bind(this);
  }

  onDismiss() {
    this.setState({ visible: false });
  }

  getDriverList = () => {
    Axios.get("/passengers/get_drivers", {}).then((res) =>
      this.setState({ drivers: res.data })
    ); //.then((res) => console.log(res));
  };

  componentDidMount() {
    this.getDriverList();
  }

  handleTrack = (id) => {
    window.localStorage.setItem("driverId", id);
  };

  renderDrivers = () => {
    return this.state.drivers.map((driver) => {
      return (
        <tr>
          <td>{driver.driver_id}</td>
          <td>{driver.username}</td>
          <td>{driver.contact}</td>
          <td>{driver.car_model}</td>
          <td>{driver.car_no}</td>
          {/* <td>{ride.status}</td>*/}
          <td>
            {" "}
            <Link to='/passenger-dashboard/passenger-feedback'>
              <Button
                className='btn btn-alert'
                onClick={() => {
                  this.handleTrack(driver.driver_id);
                }}
              >
                Track
              </Button>
            </Link>{" "}
          </td>
        </tr>
      );
    });
  };
  render() {
    return (
      <div className='animated fadeIn'>
        <Row>
          <Col xs='12' md='12'>
            <Card>
              <CardHeader>
                <i className='fa fa-align-justify'></i>
                <strong>All Drivers</strong>
                {/* <small> use <code>.alert-link</code> to provide links</small> */}
              </CardHeader>
              <CardBody>
                <Table>
                  <th>Driver Id</th>
                  <th>Name</th>
                  <th>Contact</th>
                  <th>Car Model</th>
                  <th>Car No</th>
                  {/* <th>Status</th>*/}
                  <th>Location</th>
                  {this.renderDrivers()}
                </Table>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
    );
  }
}

export default PassengerMessages;
