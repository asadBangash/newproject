
// import React, { useEffect, useState } from "react";
// import GoogleMapReact from "google-map-react";
// import { faCoffee } from "@fortawesome/free-solid-svg-icons";
// import "./style.css";
// import Marker from "./marker";
// const AnyReactComponent = ({ text }) => (
//   <div
//     className='pin'
//     style={{ backgroundColor: "red", cursor: "pointer" }}
//   ></div>
// );

// const Location = (props) => {
//   const [driverId, setDriverId] = useState("");
//   const [locations, setLocations] = useState([]);
//   let pickUpLatitude = 0;
//   let pickUpLongitude = 0;
//   let dropOffLatitude = 0;
//   let dropOffLongitude = 0;

//   const getLocation = async () => {
//     try {
//       const id = parseInt(window.localStorage.getItem("driverId"));
//       const response = await fetch(`http://localhost:5000/location/${id}`, {
//         method: "GET",
//       });

//       let parseData = await response.json();
//       console.log(parseData[0].select_pickup_location);
//       console.log(parseData[0].select_dropoff_location);

//       if (parseData[0].select_pickup_location == "Gujrat") {
//         pickUpLatitude = 32.574935;
//         pickUpLongitude = 74.0195651;
//       }

//       if (parseData[0].select_dropoff_location == "Lahore") {
//         dropOffLatitude = 31.52037;
//         dropOffLongitude = 74.358749;
//       }

//       console.log(`${pickUpLatitude}, ${pickUpLongitude}`);
//       console.log(`${dropOffLatitude}, ${dropOffLongitude}`);
//     } catch (error) {
//       console.error(error.message);
//       console.log("Error in getting locations");
//     }
//   };

//   const getDriverId = () => {
//     setDriverId(parseInt(window.localStorage.getItem("driverId")));
//     getLocation(driverId);
//   };

//   useEffect(() => {
//     getDriverId();
//   }, []);

//   const getMapOptions = (maps) => {
//     return {
//       disableDefaultUI: true,
//       mapTypeControl: true,
//       streetViewControl: true,
//       styles: [
//         {
//           featureType: "poi",
//           elementType: "labels",
//           stylers: [{ visibility: "on" }],
//         },
//       ],
//     };
//   };

//   return (
//     // Important! Always set the container height explicitly

//     <GoogleMapReact
//       defaultCenter={{
//         lat: 32.574935,
//         lng: 74.0195651,
//       }}
//       defaultZoom={11}
//       style={{ width: "500px", height: "300px" }}
//     >
//       <AnyReactComponent lat={32.574935} lng={74.0195651} text={"Pick Up"} />
//       <AnyReactComponent lat={31.52037} lng={74.358749} text={"Pick Up"} />
//     </GoogleMapReact>
//   );
// };

// export default Location;

// // import React from 'react'
// // import { Link } from 'react-router-dom';
// // import PlacesAutocomplete, {
// //   geocodeByAddress,
// //   getLatLng,
// // } from 'react-places-autocomplete';
// // import { maps, GoogleApiWrapper } from 'google-maps-react';

// // /**
// // * @author
// // * @function PassengerFeedback
// // **/

// // const PassengerFeedback = (props) => {

// //   var x  = navigator.geolocation;

// //   var y = x.getCurrentPosition(success, failure);

// //   var google;

// //   function success(position)
// //   {
// //     var myLat = position.coords.latitude;
// //     var myLong = position.coords.longitude;

// //     var coords = new google.maps.LatLng(myLat,myLong);

// //     var mapOptions = {

// //       zoom: 9,
// //       center: coords,
// //       mapTypeId: google.maps.MapTypeId.ROADMAP
// //     }

// //     var map = new google.maps.Map(document.getElementById("map"), mapOptions);
// //     var marker = new google.maps.Marker({map:map, position:coords});
// //   }

// //   function failure(){}

// //   return(
// //     <div id="map"></div>
// //    )

// //  }

// // export default PassengerFeedback

// import React from 'react'

// /**
// * @author
// * @function PassengerFeedback
// **/

// const PassengerFeedback = (props) => {
//   return(
//     <div>PassengerFeedback</div>
//    )

//  }

// export default PassengerFeedback

import React, { useEffect, useState } from "react";
import GoogleMapReact from "google-map-react";
import { faCoffee } from "@fortawesome/free-solid-svg-icons";
import "./style.css";
import Marker from "./marker";
const AnyReactComponent = ({ text }) => (
  <div
    className='pin'
    style={{ backgroundColor: "red", cursor: "pointer" }}
  ></div>
);

const Location = (props) => {
  const [driverId, setDriverId] = useState("");
  const [locations, setLocations] = useState([]);
  const [getPickupLoc, setPickupLoc] = useState();
  const [getDropoffLoc, setDropoffLoc] = useState();

  let pickUpLatitude = 0;
  let pickUpLongitude = 0;
  let dropOffLatitude = 0;
  let dropOffLongitude = 0;

  const getLocation = async () => {
    try {
      const id = parseInt(window.localStorage.getItem("driverId"));
      const response = await fetch(`http://localhost:5000/location/${id}`, {
        method: "GET",
      });

      let parseData = await response.json();

      const loc1 = await fetch(`https://maps.googleapis.com/maps/api/geocode/json?address=${parseData[0].select_pickup_location}&key=AIzaSyBBH9972aHYmizCjcRXWa7xm3DIAAZQSGU`, {
        method: "GET"
      });

      let pickupLoc = await loc1.json();
      console.log('loc pickup is', pickupLoc.results[0].geometry.location);
      setPickupLoc(pickupLoc.results[0].geometry.location)
      ///////////////

      const loc2 = await fetch(`https://maps.googleapis.com/maps/api/geocode/json?address=${parseData[0].select_dropoff_location}&key=AIzaSyBBH9972aHYmizCjcRXWa7xm3DIAAZQSGU`, {
        method: "GET"
      });

      let dropoffLoc = await loc2.json();
      console.log('loc dropOff is', dropoffLoc.results[0].geometry.location);
      setDropoffLoc(dropoffLoc.results[0].geometry.location)


      console.log('parseData is ', parseData)
      console.log(parseData[0].select_pickup_location);
      console.log(parseData[0].select_dropoff_location);

      // if (parseData[0].select_pickup_location == "Gujrat") {
      //   pickUpLatitude = 32.574935;
      //   pickUpLongitude = 74.0195651;
      // }

      // if (parseData[0].select_dropoff_location == "Lahore") {
      //   dropOffLatitude = 31.52037;
      //   dropOffLongitude = 74.358749;
      // }

      console.log(`${pickUpLatitude}, ${pickUpLongitude}`);
      console.log(`${dropOffLatitude}, ${dropOffLongitude}`);
    } catch (error) {
      console.error(error.message);
      console.log("Error in getting locations");
    }
  };

  const getDriverId = () => {
    setDriverId(parseInt(window.localStorage.getItem("driverId")));
    getLocation(driverId);
  };

  useEffect(() => {
    getDriverId();
  }, []);

  const getMapOptions = (maps) => {
    return {
      disableDefaultUI: true,
      mapTypeControl: true,
      streetViewControl: true,
      styles: [
        {
          featureType: "poi",
          elementType: "labels",
          stylers: [{ visibility: "on" }],
        },
      ],
    };
  };

  return (
    // Important! Always set the container height explicitly

    getPickupLoc && getDropoffLoc ?
      <GoogleMapReact
        defaultCenter={{
          lat: 34.0151,
          lng: 71.5249,
        }}
        defaultZoom={11}
        style={{ width: "500px", height: "300px" }}
      >
        {/* <AnyReactComponent lat={32.574935} lng={74.0195651} text={"Pick Up"} />
      <AnyReactComponent lat={31.52037} lng={74.358749} text={"Pick Up"} /> */}
        {/* {console.log('required location for pickup is ', getPickupLoc)} */}
        <AnyReactComponent lat={getPickupLoc.lat} lng={getPickupLoc.lng} ></AnyReactComponent>
        <AnyReactComponent lat={getDropoffLoc.lat} lng={getDropoffLoc.lng} ></AnyReactComponent>
      </GoogleMapReact> : null
  );
};

export default Location;
