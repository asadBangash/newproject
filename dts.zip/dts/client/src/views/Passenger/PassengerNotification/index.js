import React, { Component } from 'react';
import { Alert, Card, CardBody, CardHeader, Col, Row ,Table, Button} from 'reactstrap';
import Axios from 'axios'
class PassengerNotifications extends Component {
  constructor(props) {
    super(props);

    this.state = {
      visible: true,
      rides:[],
      rideUpdate:false
    };

    this.onDismiss = this.onDismiss.bind(this);
  }

  onDismiss() {
    this.setState({ visible: false });
  }

  getRideList = ()=>{
    const token_jwt = localStorage.getItem("usertoken");
  Axios.post("/passengers/get_recent_rides",{} , {
    headers: {
      "x-auth-token": token_jwt,
    },
  }).then((res) => this.setState({rides:res.data}));

  }
componentDidMount(){
  this.getRideList()

}

cancelRide = (rideId)=>{
  console.log(rideId);
  const token_jwt = localStorage.getItem("usertoken");
  Axios.post("/passengers/cancel_ride",{rideId} , {
    headers: {
      "x-auth-token": token_jwt,
    },
  }).then(ride=>{
    this.getRideList()
  });


}

renderRides = ()=>{
 return this.state.rides.map((ride)=>{
  return (
    <tr>
      <td>{ride.ride_id}</td>
      <td>{ride.pickupLocation}</td>
      <td>{ride.dropoffLocation}</td>
      <td>{ride.numberOfSeats}</td>
      <td>{ride.totalPrice}</td>
      <td>{ride.status}</td>
      <td> {ride.status ==='placed' ?<Button onClick={()=>{this.cancelRide(ride.ride_id);this.getRideList()}} className="btn btn-danger">Cancel</Button>:<Button disabled  className="btn btn-danger">Cancel</Button>}  </td>
    </tr>
  )
})
}
  render() {
    return (
      <div className="animated fadeIn">
        <Row>
          
          <Col xs="12" md="12">
            <Card>
              <CardHeader>
                <i className="fa fa-align-justify"></i><strong>My Recent Rides</strong>
                {/* <small> use <code>.alert-link</code> to provide links</small> */}
              </CardHeader>
              <CardBody>
               <Table>
                 
                  <th>Ride Id</th>
                  <th>PickUp Location</th>
                  <th>Dropoff Location</th>
                  <th>Number of Seats</th>
                  <th>Total Price</th>
                  <th>Status</th>
                  <th>Action</th>
                  {this.renderRides()}
               </Table>
              </CardBody>
            </Card>
          </Col>
        </Row>
        
      </div>
    );
  }
}

export default PassengerNotifications;
