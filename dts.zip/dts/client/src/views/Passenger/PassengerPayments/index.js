import React, { Component } from 'react';
import {
  Button,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  Col,
  Alert,
  Row,
} from 'reactstrap';

import Axios from 'axios';

class PassengerPayments extends Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.toggleFade = this.toggleFade.bind(this);
    this.state = {
      collapse: true,
      fadeIn: true,
      timeout: 300,
      recepits: [],
    };
  }
  componentDidMount() {
    const token_jwt = localStorage.getItem('usertoken');
    Axios.post(
      '/passengers/get_recepits',
      {},
      {
        headers: {
          'x-auth-token': token_jwt,
        },
      }
    ).then((res) => {
      this.setState({ recepits: res.data });
      console.log(res);
    });
  }
  toggle() {
    this.setState({ collapse: !this.state.collapse });
  }

  toggleFade() {
    this.setState((prevState) => {
      return { fadeIn: !prevState };
    });
  }

  renderRecepits = () => {
    return this.state.recepits.map((recept) => {
      console.log(recept);
      return (
        <Alert color='primary'>
          <a target='blank' href={recept.recepit}>
            {recept.recepit}
          </a>
        </Alert>
      );
    });
  };

  render() {
    return (
      <div className='animated fadeIn'>
        <Row>
          <Col>
            <Card>
              <CardHeader>
                <strong>Payments Recepits</strong>
              </CardHeader>
              <CardBody>
                <Row>
                  <Col xs='12'>{this.renderRecepits()}</Col>
                </Row>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
    );
  }
}

export default PassengerPayments;
