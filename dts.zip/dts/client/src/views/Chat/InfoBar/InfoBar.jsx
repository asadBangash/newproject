import React from 'react';
import { Link, NavLink } from 'react-router-dom';

import onlineIcon from '../../icons/onlineIcon.png';
import closeIcon from '../../icons/closeIcon.png';

import './InfoBar.css';

const setRoom = room => {
  const splitRoom = room.split('-');
  const driver = splitRoom[0].split('@')[0];
  const passenger = splitRoom[2].split('@')[0];
  const admin = splitRoom[4].split('@')[0];

  return `${driver} & ${passenger} & ${admin} Room`;
};
const InfoBar = ({ room, url }) => (
  <div className='infoBar'>
    <div className='leftInnerContainer'>
      <img className='onlineIcon' src={onlineIcon} alt='online icon' />
      <h4>Private Room</h4>
    </div>
    <div className='rightInnerContainer'>
      <Link to={`/${url}`}>
        <img src={closeIcon} alt='close icon' />
      </Link>
    </div>
  </div>
);

export default InfoBar;
