import React, { Component } from "react";
import io from "socket.io-client";
import { Alert } from "reactstrap";
import Axios from "axios";
import {useParams} from "react-router-dom";
class Layout extends Component {
  constructor(props) {
    super(props);
    this.state = {
      socket: null,
      user: null,
      message1: "",
      message: [],
      sender: "",
      receiver: "",
    };
  }

  componentDidMount() {
    console.log(this.props);
    const socket = io.connect("http://localhost:5000/");
    socket.on("connect", () => {
      console.log("connected!");
    });
    this.setState({ socket,receiver:this.props.receiver });
    const token_jwt = localStorage.getItem("usertoken");
    Axios.post(
      "/passengers/onlineUserInfo",
      {},
      {
        headers: {
          "x-auth-token": token_jwt,
        },
      }
    ).then((res) => {
      console.log(res);
      socket.emit("user_connected", res.data.email);
      socket.on("user_connected", function (username) {
        console.log(username);
      });
      this.setState({ user: res.data.first_name,sender:res.data.email });
    });
  }


  handleSubmit = (e) => {
    e.preventDefault();

    this.state.socket.emit("send_message", {
		  sender: this.state.sender,
		  receiver: this.state.receiver,
		  message: this.state.message1
    });

    
    this.state.socket.on("new_message", function (data) {
      console.log(data);
    });
  };

  receiverMessage = () => {
  
  };

  render() {
    return (
      <div>
        <form onSubmit={this.handleSubmit}>
          <label>
            Name:
            <input
              type="text"
              value={this.state.message1}
              onChange={(e) => this.setState({ message1: e.target.value })}
            />
          </label>
          <input type="submit" value="Submit" />
        </form>
      </div>
    );
  }
}

export default Layout;
