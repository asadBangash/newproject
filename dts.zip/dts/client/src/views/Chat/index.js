import React from 'react'
// import Layout from './Layout'
import Layout from './Chat/Chat';
const Chat = ({ match }) => {
    localStorage.setItem('msgReceiver', match.params.email);
    const emailUrl = match.params.email;
    const url = match.path.split('/')[1];
    return (
        <div>
            <Layout title="Chat app" emailUrl={(emailUrl)} url={(url)} />
        </div>
    )
}
export default Chat;
