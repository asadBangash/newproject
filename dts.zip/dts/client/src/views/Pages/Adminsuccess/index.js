import React from 'react';
import './style.css';
import { Link } from 'react-router-dom';
import { Button, Card, CardBody, CardGroup, Col, Container, Form, Input, InputGroup, InputGroupAddon, InputGroupText, Row } from 'reactstrap';


import logo from './logo.png';

console.log(logo);
/**
* @author
* @function Landing
**/

const Adminsuccess = (props) => {
  return(
    <container>
    <header className="header">
    <img src={logo} className="logo" alt="Logo" />;
        
        <h1>Destination Travel System</h1> 
        
    </header>
    <section className="section">
    <center><div>
      <h1>You are successfully registered to Destination Travel System</h1>
    <Link to="/adminlogin">
    <Button className="btn1">Login</Button>
    </Link>
      </div></center>
    
      </section>
    </container>
   );

 }

export default Adminsuccess