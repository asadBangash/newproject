import React from 'react';



/**
* @author
* @function Choose
**/

const Choose = (props) => {
  return(
    <div>Choose</div>
   )

 }

export default Choose