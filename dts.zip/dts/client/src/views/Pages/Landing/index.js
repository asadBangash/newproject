import React from 'react';
import './style.css';
import { Link } from 'react-router-dom';
import { Button, Card, CardBody, CardGroup, Col, Container, Form, Input, InputGroup, InputGroupAddon, InputGroupText, Row } from 'reactstrap';

import logo from './logo.png';

console.log(logo);
/**
* @author
* @function Landing
**/

const Landing = (props) => {
  return(

    <div className=" align-items-center">
        <header className="header">
        <img src={logo} className="logo" alt="Logo" />
               <div>
        
        <h1>Destination Travel System</h1> 
        </div>
    </header>

    <Container className="section">
    <section className="section">
    <center><div>
    <Link to="/driverchoose">
    <Button className="btn1">Driver</Button>
    </Link>
      </div></center>
    <br></br>
    <center><div>
    <Link to="/passengerchoose">
    <Button className="btn1">Passenger</Button>
    </Link>
    </div></center>
      </section>
    </Container>
    </div>
   );

 }

export default Landing;