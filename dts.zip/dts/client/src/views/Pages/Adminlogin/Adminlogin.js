import React, { Component } from 'react';
import './style.css';
import { Link } from 'react-router-dom';
import { login } from '../components/UserFunctions2'

import { Button, Card, CardBody, CardGroup, Col, Container, Form, Input, InputGroup, InputGroupAddon, InputGroupText, Row, Alert } from 'reactstrap';

import logo from './logo.png';

console.log(logo);

class Adminlogin extends Component {

  constructor() {
    super()
    this.state = {
      email: '',
      password: '',
      errors: {},
      Showerror: false
    }

    this.onChange = this.onChange.bind(this)
    this.onSubmit = this.onSubmit.bind(this)
  }

  onChange(e) {

    this.setState({ Showerror: false })
    this.setState({ [e.target.name]: e.target.value })
  }

  validate = () => {
    let emailError = "";
    let passwordError = "";


    // if(!this.state.email.includes('@')){
    //   emailError = 'invalid email';
    // }

    if (!this.state.email) {
      emailError = 'please type email';
    }
    if (!this.state.password) {
      passwordError = 'please type password';
    }

    if (emailError || passwordError) {
      this.setState({ emailError, passwordError });
      return false;
    }
    return true;

  };


  onSubmit(e) {
    e.preventDefault()

    e.preventDefault()
    const isValid = this.validate();

    const admin = {
      email: this.state.email,
      password: this.state.password
    }


    // login(admin).then(res => {
    //   if (res.error) {
    //     this.setState({ Showerror: true })
    //   } else {
    //     this.props.history.push('/admin-dashboard/admin-dashboard')
    //   }
    // })

    if (isValid) {
      login(admin).then(res => {

        console.log(res);
        if (res.error) {
          this.setState({ Showerror: true })
        } else {
          this.props.history.push('/admin-dashboard/admin-dashboard')
        }
      })
    }
  }
  render() {
    return (
      <div className=" align-items-center">
        <header className="header">
          <img src={logo} className="logo" alt="Logo" />
          <div>

            <h1>Destination Travel System</h1>
          </div>
        </header>

        <Container>

          <section className="section">

          </section>

          <Row className="justify-content-center">
            <Col md="8">
              <CardGroup>
                <Card className="p-4">
                  <CardBody>
                    {
                      this.state.Showerror &&
                      <Alert color="danger">
                        Invalid Credentials
                  </Alert>}
                    <Form noValidate onSubmit={this.onSubmit}>
                      <h1>Login</h1>
                      <p className="text-muted">Sign In to your account</p>

                      <InputGroup className="mb-3">
                        <InputGroupAddon addonType="prepend">
                        </InputGroupAddon>
                        <Input type="email"
                          placeholder="Enter email"
                          autoComplete="email"
                          name="email"
                          value={this.state.email}
                          onChange={this.onChange} />
                      </InputGroup>
                      <div style={{ fontSize: 12, color: "red" }}>
                        {this.state.emailError}
                      </div>

                      <InputGroup className="mb-4">
                        <InputGroupAddon addonType="prepend">
                        </InputGroupAddon>
                        <Input type="password"
                          placeholder="Password"
                          autoComplete="current-password"
                          name="password"
                          value={this.state.password}
                          onChange={this.onChange}
                        />
                      </InputGroup>
                      <div style={{ fontSize: 12, color: "red" }}>
                        {this.state.passwordError}
                      </div>
                      <Row>
                        <Col xs="6">
                          <Button type="submit" color="primary" className="px-4">Login</Button>
                        </Col>
                        <Col xs="6" className="text-right">
                          <Link to="/forgetpassword"><Button color="link" className="px-0">Forgot password?</Button></Link>
                        </Col>
                      </Row>
                    </Form>
                  </CardBody>
                </Card>

              </CardGroup>
            </Col>
          </Row>

        </Container>
      </div>
    );
  }
}

export default Adminlogin;
