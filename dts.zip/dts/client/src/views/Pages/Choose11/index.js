import React from 'react';
import './style.css';
import { Link } from 'react-router-dom';
import { Button, Card, CardBody, CardGroup, Col, Container, Form, Input, InputGroup, InputGroupAddon, InputGroupText, Row } from 'reactstrap';


import logo from './logo.jpg';

console.log(logo);
/**
* @author
* @function Landing
**/

const Landing = (props) => {
  return(
    <container>
    <header className="header">
    <img src={logo} className="logo" alt="Logo" />;
        
        <h1>Destination Travel System</h1> 
        
    </header>
    <section className="section">
    <center><div>
    <Link to="/registerdriver">
    <Button className="btn1">Register as a Driver</Button>
    </Link>
      </div></center>
    <br></br>
    <center><div>
    <Link to="/registerpassenger">
    <Button className="btn1">Register as a Customer</Button>
    </Link>
    </div></center>
      </section>
    </container>
   );

 }

export default Landing