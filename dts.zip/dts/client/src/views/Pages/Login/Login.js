import React, { Component } from 'react';
import './style.css';
import { Link } from 'react-router-dom';
import { login } from '../components/UserFunctions'

import { Button, Card, CardBody, CardGroup, Col, Container, Form, Input, InputGroup, InputGroupAddon, InputGroupText, Row } from 'reactstrap';

import logo from './logo.png';

console.log(logo);

class Login extends Component {

  constructor() {
    super()
    this.state = {
      email: '',
      password: '',
      errors: {}
    }

    this.onChange = this.onChange.bind(this)
    this.onSubmit = this.onSubmit.bind(this)
  }

  onChange(e) {
    this.setState({ [e.target.name]: e.target.value })
  }
  onSubmit(e) {
    e.preventDefault()

    const driver = {
      email: this.state.email,
      password: this.state.password
    }

    login(driver).then(res => {
      if (res) {
        this.props.history.push('/driver-dashboard')
      }
    })
  }
  render() {
    return (
      <div className=" align-items-center">
        <header className="header">
        <img src={logo} className="logo" alt="Logo" />
               <div>
        
        <h1>Destination Travel System</h1> 
        </div>
    </header>

    <Container>

    <section className="section">
     
    </section>
      
          <Row className="justify-content-center">
            <Col md="8">
              <CardGroup>
                <Card className="p-4">
                  <CardBody>
                    <Form noValidate onSubmit={this.onSubmit}>
                      <h1>Login</h1>
                      <p className="text-muted">Sign In to your account</p>

                      <InputGroup className="mb-3">
                        <InputGroupAddon addonType="prepend">
                        </InputGroupAddon>
                        <Input type="email"
                          placeholder="Enter email"
                          autoComplete="email" 
                          name="email" 
                          value={this.state.email}
                          onChange={this.onChange} />
                      </InputGroup>

                      <InputGroup className="mb-4">
                        <InputGroupAddon addonType="prepend">
                        </InputGroupAddon>
                        <Input type="password" 
                        placeholder="Password" 
                        autoComplete="current-password" 
                        name="password" 
                        value={this.state.password}
                        onChange={this.onChange}
                        />
                      </InputGroup>
                      <Row>
                        <Col xs="6">
                          <Button type="submit" color="primary" className="px-4">Login</Button>
                        </Col>
                        <Col xs="6" className="text-right">
                        <Link to="/forgetpassword"><Button color="link" className="px-0">Forgot password?</Button></Link>
                        </Col>
                      </Row>
                    </Form>
                  </CardBody>
                </Card>

              </CardGroup>
            </Col>
          </Row>
  
        </Container>
      </div>
    );
  }
}

export default Login;
