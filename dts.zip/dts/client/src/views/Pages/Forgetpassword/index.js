import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { Button, Card, CardBody, CardFooter, Col, Container, Form, Input, InputGroup, InputGroupAddon, InputGroupText, Row } from 'reactstrap';
import "./style.css";
import logo from './logo.png';

console.log(logo);

class Forgetpassword extends Component {
  
  render() {
    return (
      <div className="align-items-center">
        <header className="header">
        <img src={logo} className="logo" alt="Logo" />;

          <h1>Destination Travel System</h1>
        </header>
        <Container className="section">
          <Row className="justify-content-center">
            <Col md="9" lg="7" xl="6">
              <Card className="mx-4">
                <CardBody className="p-4">
                  <Form>
                    <h1>Reset Password </h1>

                    <InputGroup className="mb-3">
                      <InputGroupAddon addonType="prepend">
                      </InputGroupAddon>
                      <Input type="text" placeholder="Enter Email" autoComplete="Enter Email" />
                    </InputGroup>

                    <Button color="success" block>Submit</Button>
                  </Form>
                </CardBody>
                
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }
}

export default Forgetpassword;
