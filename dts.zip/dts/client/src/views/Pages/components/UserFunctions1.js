import axios from 'axios';

export const register = (newUser) => {
  return axios
    .post('passengers/registerpassenger', {
      first_name: newUser.first_name,
      last_name: newUser.last_name,
      username: newUser.username,
      contact: newUser.contact,
      gender: newUser.gender,
      route: newUser.route,

      email: newUser.email,
      password: newUser.password,

      created: newUser.created,
    })
    .then((response) => {
      return response;
      console.log('Registered');
    }).catch(err => {
      return err.response.data;
    });
};

export const login = (passenger) => {
  const email = passenger.email;
  return axios
    .post('passengers/passengerlogin', {
      email: email,
      password: passenger.password,
    })
    .then((response) => {
      localStorage.setItem('usertoken', response.data);
      localStorage.setItem('loginUser', email);
      return response.data;
    })
    .catch((err) => {
      console.log(err);
      return err.response.data;

    });
};

export const notification = () => {
  const passenger_email = localStorage.getItem('loginUser');
  return axios
    .post('/admins/getNotification', {
      passenger_email,
    })
    .then((response) => {
      return response.data;
    })
    .catch((err) => {
      console.log(err);
    });
};
