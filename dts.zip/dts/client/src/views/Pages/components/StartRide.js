import axios from 'axios'

export const startride = startRide => {
  return axios
    .post('startrides/start-rides', {
        select_pickup_location: startRide.select_pickup_location,
        select_dropoff_location: startRide.select_dropoff_location,
        number_of_seats_available: startRide.number_of_seats_available,
        enter_price: startRide.enter_price
      
    })
    // .then(response => {
    //   console.log('Started')
    // })
}



