import React, { Component } from 'react';
import {
  Button,
  Card,
  CardBody,
  CardFooter,
  Col,
  Container,
  Form,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Row,
  Alert,
} from 'reactstrap';
import './style.css';
import logo from './logo.png';
import { register } from '../components/UserFunctions1';

console.log(logo);

class Registerpassenger extends Component {
  constructor() {
    super();
    this.state = {
      first_name: '',
      last_name: '',
      username: '',
      contact: '',
      gender: '',
      route: '',

      email: '',
      password: '',
      confirmpassword: '',

      created: '',
      errors: {},
      errormsg: '',
    };

    this.onChange = this.onChange.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
  }

  onChange(e) {
    this.setState({ errormsg: null });
    this.setState({ [e.target.name]: e.target.value });
  }

  validate = () => {
    let first_nameError = '';
    let last_nameError = '';
    let usernameError = '';
    let contactError = '';
    let genderError = '';
    let routeError = '';
    let emailError = '';
    let passwordError = '';
    let confirmpasswordError = '';
    let passworderror = '';

    // if(!this.state.email.includes('@')){
    //   emailError = 'invalid email';
    // }
    if (!this.state.first_name) {
      first_nameError = 'please type first name';
    }
    if (!this.state.last_name) {
      last_nameError = 'please type last name';
    }
    if (!this.state.username) {
      usernameError = 'please type username';
    }
    if (!this.state.contact) {
      contactError = 'please type contact';
    }
    if (!this.state.gender) {
      genderError = 'please type gender';
    }
    if (!this.state.route) {
      routeError = 'please type route';
    }
    if (!this.state.email) {
      emailError = 'please type email';
    }
    if (!this.state.password) {
      passwordError = 'please type password';
    }
    if (!this.state.confirmpassword) {
      confirmpasswordError = 'please type confirm password';
    }
    const { password, confirmpassword } = this.state;
    if (password !== confirmpassword) {
      passworderror = 'password dont match';
  }

    if (
      first_nameError ||
      last_nameError ||
      usernameError ||
      contactError ||
      genderError ||
      routeError ||
      emailError ||
      passwordError ||
      confirmpasswordError ||
      passworderror
    ) {
      this.setState({
        first_nameError,
        last_nameError,
        usernameError,
        contactError,
        genderError,
        routeError,
        emailError,
        passwordError,
        confirmpasswordError,
        passworderror,
      });
      return false;
    }
    return true;
  };
  
  // handleSubmit = () => {
  //   const { password, confirmPassword } = this.state;
  //   // perform all neccassary validations
  //   if (password !== confirmPassword) {
  //       alert("Passwords don't match");
  //   }}
  
  onSubmit(e) {
    e.preventDefault();
    const isValid = this.validate();
    const newUser = {
      first_name: this.state.first_name,
      last_name: this.state.last_name,
      username: this.state.username,
      contact: this.state.contact,
      gender: this.state.gender,
      route: this.state.route,

      email: this.state.email,
      password: this.state.password,

      created: this.state.created,
    };
    if (isValid) {
      register(newUser).then((res) => {
        // 
        if (res.error) {
          this.setState({ errormsg: res.error });
        } else {

          this.props.history.push('/passengersuccess');
        }
      });
    }
  }

  render() {
    return (
      <div className='align-items-center'>
        <header className='header'>
          <img src={logo} className='logo' alt='Logo' />;
          <h1>Destination Travel System</h1>
        </header>
        <Container className='section'>
          <Row className='justify-content-center'>
            <Col md='9' lg='7' xl='6'>
              <Card className='mx-4'>
                <CardBody className='p-4'>
                  {this.state.errormsg &&
                    <Alert color="danger">
                      {this.state.errormsg}
                    </Alert>

                  }
                  {this.state.passworderror &&
                    <Alert color="danger">
                      {this.state.passworderror}
                    </Alert>

                  }
                  <Form onSubmit={this.onSubmit}>
                    <h1>Register As Passenger</h1>
                    <p className='text-muted'>Create your account</p>

                    <Row>
                      <Col xs='12' sm='6'>
                        <InputGroup className='mb-3'>
                          <InputGroupAddon addonType='prepend'></InputGroupAddon>
                          <Input
                            type='text'
                            placeholder='First Name'
                            name='first_name'
                            value={this.state.first_name}
                            onChange={this.onChange}
                          />
                        </InputGroup>
                        <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.first_nameError}
                        </div>
                      </Col>

                      <Col xs='12' sm='6'>
                        <InputGroup className='mb-3'>
                          <InputGroupAddon addonType='prepend'></InputGroupAddon>
                          <Input
                            type='text'
                            placeholder='Last Name'
                            name='last_name'
                            value={this.state.last_name}
                            onChange={this.onChange}
                          />
                        </InputGroup>
                        <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.last_nameError}
                        </div>
                      </Col>
                    </Row>

                    <Row>
                      <Col xs='12' sm='6'>
                        <InputGroup className='mb-3'>
                          <InputGroupAddon addonType='prepend'></InputGroupAddon>
                          <Input
                            type='text'
                            placeholder='Username'
                            name='username'
                            value={this.state.username}
                            onChange={this.onChange}
                          />
                        </InputGroup>
                        <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.usernameError}
                        </div>
                      </Col>

                      <Col xs='12' sm='6'>
                        <InputGroup className='mb-3'>
                          <InputGroupAddon addonType='prepend'></InputGroupAddon>
                          <Input
                            type='text'
                            placeholder='Contact'
                            name='contact'
                            value={this.state.contact}
                            onChange={this.onChange}
                          />
                        </InputGroup>
                        <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.contactError}
                        </div>
                      </Col>
                    </Row>

                    <Row>
                      <Col xs='12' sm='6'>
                        <InputGroupAddon addonType='prepend'></InputGroupAddon>
                        {/* <Input type="text" 
                   placeholder="Gender" 
                   name="gender"
                   value={this.state.gender}
                   onChange={this.onChange}
                   /> */}
                        <Input
                          type='select'
                          name='gender'
                          id='exampleSelect'
                          value={this.state.gender}
                          onChange={this.onChange}
                        >
                          <option>Select</option>
                          <option>Female</option>
                          <option>Male</option>
                        </Input>

                        <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.genderError}
                        </div>
                      </Col>

                      <Col xs='12' sm='6'>
                        <InputGroup className='mb-3'>
                          <InputGroupAddon addonType='prepend'></InputGroupAddon>
                          <Input
                            type='text'
                            placeholder='Route'
                            name='route'
                            value={this.state.route}
                            onChange={this.onChange}
                          />
                        </InputGroup>
                        <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.routeError}
                        </div>
                      </Col>
                    </Row>

                    <Row>
                      <Col xs='12' sm='6'>
                        <InputGroup className='mb-3'>
                          <InputGroupAddon addonType='prepend'></InputGroupAddon>
                          <Input
                            type='email'
                            placeholder='Email'
                            name='email'
                            value={this.state.email}
                            onChange={this.onChange}
                          />
                        </InputGroup>
                        <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.emailError}
                        </div>
                      </Col>

                      <Col xs='12' sm='6'>
                        <InputGroup className='mb-3'>
                          <InputGroupAddon addonType='prepend'></InputGroupAddon>
                          <Input
                            type='password'
                            placeholder='Password'
                            name='password'
                            value={this.state.password}
                            onChange={this.onChange}
                          />
                        </InputGroup>
                        <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.passwordError}
                        </div>
                      </Col>
                      
                    </Row>
                    <Row>
                      

                      <Col xs='12' sm='6'>
                        <InputGroup className='mb-3'>
                          <InputGroupAddon addonType='prepend'></InputGroupAddon>
                          <Input
                            type='password'
                            placeholder='confirm Password'
                            name='confirmpassword'
                            value={this.state.confirmpassword}
                            onChange={this.onChange}
                          />
                        </InputGroup>
                        <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.confirmpasswordError}
                        </div>
                      </Col>
                      
                    </Row>

                    <Button type='submit' color='success' block>
                      Create Account
                    </Button>
                  </Form>

                </CardBody>

                {/* <CardFooter className="p-4">

                  <Row>
                    <Col xs="12" sm="6">
                      <Button className="btn-facebook mb-1" block><span>facebook</span></Button>
                    </Col>
                    <Col xs="12" sm="6">
                      <Button className="btn-twitter mb-1" block><span>twitter</span></Button>
                    </Col>
                  </Row>
                  
                </CardFooter> */}
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }
}

export default Registerpassenger;
