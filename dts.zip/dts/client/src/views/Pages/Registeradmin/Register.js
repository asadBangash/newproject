import React, { Component } from 'react';
import {
  Button,
  Card,
  CardBody,
  CardFooter,
  Col,
  Container,
  Form,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Row,
  Alert,
} from 'reactstrap';
import './style.css';
import logo from './logo.png';
import { register } from '../components/UserFunctions2';

console.log(logo);

class Register extends Component {
  constructor() {
    super();
    this.state = {
      first_name: '',
      last_name: '',
      username: '',

      email: '',
      password: '',
      confirmpassword: '',
      created: '',
      errors: {},
      errormsg: null,
    };

    this.onChange = this.onChange.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
  }

  onChange(e) {

    this.setState({ errormsg: null });
    this.setState({ [e.target.name]: e.target.value });
  }

  validate = () => {
    let first_nameError = '';
    let last_nameError = '';
    let usernameError = '';

    let emailError = '';
    let passwordError = '';
    let confirmpasswordError = '';
    let passworderror = '';

    // if(!this.state.email.includes('@')){
    //   emailError = 'invalid email';
    // }
    if (!this.state.first_name) {
      first_nameError = 'please type first name';
    }
    if (!this.state.last_name) {
      last_nameError = 'please type last name';
    }
    if (!this.state.username) {
      usernameError = 'please type username';
    }

    if (!this.state.email) {
      emailError = 'please type email';
    }
    if (!this.state.password) {
      passwordError = 'please type password';
    }
    if (!this.state.confirmpassword) {
      confirmpasswordError = 'please type confirm password';
    }
    const { password, confirmpassword } = this.state;
    if (password !== confirmpassword) {
      passworderror = 'password dont match';
  }

    if (
      first_nameError ||
      last_nameError ||
      usernameError ||
      emailError ||
      passwordError ||
      confirmpasswordError ||
      passworderror
    ) {
      this.setState({
        first_nameError,
        last_nameError,
        usernameError,
        emailError,
        passwordError,
        confirmpasswordError,
        passworderror,
      });
      return false;
    }
    return true;
  };

  onSubmit(e) {
    e.preventDefault();
    const isValid = this.validate();
    const newUser = {
      first_name: this.state.first_name,
      last_name: this.state.last_name,
      username: this.state.username,

      email: this.state.email,
      password: this.state.password,

      created: this.state.created,
    };
    if (isValid) {
      register(newUser).then((res) => {

        if (res.error) {
          this.setState({ errormsg: res.error });
        } else {
          this.props.history.push('/adminsuccess');
        }
      });
    }
  }

  render() {
    return (
      <div className='align-items-center'>
        <header className='header'>
          <img src={logo} className='logo' alt='Logo' />;
          <h1>Destination Travel System</h1>
        </header>
        <Container className='section'>
          <Row className='justify-content-center'>
            <Col md='9' lg='7' xl='6'>
              <Card className='mx-4'>
                <CardBody className='p-4'>
                  {this.state.errormsg &&
                    <Alert color="danger">
                      {this.state.errormsg}
                    </Alert>
                  }
                  {this.state.passworderror &&
                    <Alert color="danger">
                      {this.state.passworderror}
                    </Alert>

                  }
                  <Form onSubmit={this.onSubmit}>
                    <h1>Register As Admin</h1>
                    <p className='text-muted'>Create your account</p>

                    <Row>
                      <Col xs='12' sm='6'>
                        <InputGroup className='mb-3'>
                          <InputGroupAddon addonType='prepend'></InputGroupAddon>
                          <Input
                            type='text'
                            placeholder='First Name'
                            name='first_name'
                            value={this.state.first_name}
                            onChange={this.onChange}
                          />
                        </InputGroup>
                        <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.first_nameError}
                        </div>
                      </Col>

                      <Col xs='12' sm='6'>
                        <InputGroup className='mb-3'>
                          <InputGroupAddon addonType='prepend'></InputGroupAddon>
                          <Input
                            type='text'
                            placeholder='Last Name'
                            name='last_name'
                            value={this.state.last_name}
                            onChange={this.onChange}
                          />
                        </InputGroup>
                        <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.last_nameError}
                        </div>
                      </Col>
                    </Row>

                    <Row>
                      <Col xs='12' sm='6'>
                        <InputGroup className='mb-3'>
                          <InputGroupAddon addonType='prepend'></InputGroupAddon>
                          <Input
                            type='text'
                            placeholder='Username'
                            name='username'
                            value={this.state.username}
                            onChange={this.onChange}
                          />
                        </InputGroup>
                        <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.usernameError}
                        </div>
                      </Col>
                    </Row>

                    <Row>
                      <Col xs='12' sm='6'>
                        <InputGroup className='mb-3'>
                          <InputGroupAddon addonType='prepend'></InputGroupAddon>
                          <Input
                            type='email'
                            placeholder='Email'
                            name='email'
                            value={this.state.email}
                            onChange={this.onChange}
                          />
                        </InputGroup>
                        <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.emailError}
                        </div>
                      </Col>

                      <Col xs='12' sm='6'>
                        <InputGroup className='mb-3'>
                          <InputGroupAddon addonType='prepend'></InputGroupAddon>
                          <Input
                            type='password'
                            placeholder='Password'
                            name='password'
                            value={this.state.password}
                            onChange={this.onChange}
                          />
                        </InputGroup>
                        <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.passwordError}
                        </div>
                      </Col>
                    </Row>
                    <Row>
                      

                      <Col xs='12' sm='6'>
                        <InputGroup className='mb-3'>
                          <InputGroupAddon addonType='prepend'></InputGroupAddon>
                          <Input
                            type='password'
                            placeholder='confirm Password'
                            name='confirmpassword'
                            value={this.state.confirmpassword}
                            onChange={this.onChange}
                          />
                        </InputGroup>
                        <div style={{ fontSize: 12, color: 'red' }}>
                          {this.state.confirmpasswordError}
                        </div>
                      </Col>
                      
                    </Row>

                    <Button type='submit' color='success' block>
                      Create Account
                    </Button>
                  </Form>
                </CardBody>
                <CardFooter className='p-4'>
                  <Row>
                    <Col xs='12' sm='6'>
                      <Button className='btn-facebook mb-1' block>
                        <span>facebook</span>
                      </Button>
                    </Col>
                    <Col xs='12' sm='6'>
                      <Button className='btn-twitter mb-1' block>
                        <span>twitter</span>
                      </Button>
                    </Col>
                  </Row>

                  <h1></h1>
                </CardFooter>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }
}

export default Register;
