export default {
  items: [
    {
      name: 'Admin Dashboard',
      url: '/admin-dashboard/admin-dashboard',
      // icon: "cui-dashboard",
      attributes: {
        exact: true,
      },
    },
    {
      name: 'Drivers',
      url: '/admin-dashboard/drivers',
      // icon: "cui-user",
      attributes: {
        exact: true,
      },
    },
    {
      name: 'Passengers',
      url: '/admin-dashboard/passengers',
      // icon: "cui-user",
      attributes: {
        exact: true,
      },
    },

    // {
    //   name: "Complaints",
    //   url: "/admin-dashboard/complaints",
    //   icon: "cui-pencil",
    //   attributes: {
    //     exact: true
    //   }
    // },

    {
      name: 'Payments',
      url: '/admin-dashboard/payments',
      // icon: "cui-dollar",
      attributes: {
        exact: true,
      },
    },

    {
      name: 'Map',
      url: '/admin-dashboard/location',
      // icon: "cui-map",
      attributes: {
        exact: true,
      },
    },

    // {
    //   name: "Settings",
    //   url: "/admin-dashboard/settings",
    //   // icon: "cui-settings",
    //   attributes: {
    //     exact: true
    //   }
    // }
  ],
};
