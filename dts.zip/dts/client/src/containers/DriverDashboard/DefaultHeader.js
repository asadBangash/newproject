import React, { Component } from 'react';
import { Link, NavLink } from 'react-router-dom';
import {
  Badge,
  UncontrolledDropdown,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Nav,
  NavItem,
} from 'reactstrap';
import PropTypes from 'prop-types';
import {
  AppAsideToggler,
  AppNavbarBrand,
  AppSidebarToggler,
} from '@coreui/react';
import logo from '../../assets/img/brand/logo.png';
import sygnet from '../../assets/img/brand/sygnet.svg';
import './style.css';
import Header from '@coreui/react/lib/Header';
import { notification } from '../../views/Pages/components/UserFunctions';

const propTypes = {
  children: PropTypes.node,
};

const defaultProps = {};
let driverDriver = {};
class DefaultHeader extends Component {
  constructor() {
    super();
    this.state = {
      data: [],
    };
  }
  componentWillMount() {
    notification().then((res) => {
      console.log('Driver Data ', res);
      // this.state.room = res.data;
      if (res) {

        if (res.data)
          this.setState({
            data: res.data,
          });
      }
      // console.log('Driver Data of Room', driverDriver.room)
    });
  }

  setRoom(room) {
    localStorage.setItem('room', room);
  }

  render() {
    if (this.props.user !== null) console.log(this.props.user);
    // eslint-disable-next-line
    const { children, ...attributes } = this.props;
    console.log('Proopes Data ', this.props);
    return (
      <Header className='header'>
        <React.Fragment>
          <AppSidebarToggler className='d-lg-none' display='md' mobile />
          <AppNavbarBrand
            full={{ src: logo, width: 89, height: 25, alt: 'CoreUI Logo' }}
            minimized={{
              src: sygnet,
              width: 30,
              height: 30,
              alt: 'CoreUI Logo',
            }}
          />
          <AppSidebarToggler className='d-md-down-none' display='lg' />
          {/* <Nav className="d-md-down-none" navbar >
          <NavItem className="px-3">
            <NavLink to="/dashboard" className="nav-link" style={{color: "white"}}>Dashboard</NavLink>
          </NavItem>
          <NavItem className="px-3">
            <Link to="/users" className="nav-link" style={{color: "white"}}>Users</Link>
          </NavItem>
          <NavItem className="px-3">
            <NavLink to="#" className="nav-link" style={{color: "white"}}>Settings</NavLink>
          </NavItem>
        </Nav> */}
          <Nav className='ml-auto' navbar>
            {/* <NavItem className='d-md-down-none'>
              <div class='search-container'>
                <form>
                  <input
                    type='text'
                    placeholder='Search..'
                    name='search'
                  ></input>
                  <button type='submit'>
                    <i class='fa fa-search'></i>
                  </button>
                </form>
              </div>
            </NavItem> */}

            <NavItem className='d-md-down-none'>
              {this.props.user !== null ? (
                <span style={{ padding: 10, color: 'white' }}>
                  {this.props.user.first_name} {this.props.user.last_name}
                </span>
              ) : null}
            </NavItem>
            <UncontrolledDropdown
              nav
              direction='down'
              style={{ color: 'white' }}
            >
              <DropdownToggle nav style={{ color: 'white' }}>
                <i className='icon-bell'></i>
                {/* <img src={'../../../assets/img/brand/logo.png'} className="img-avatar" alt="Admin" /> */}
              </DropdownToggle>
              <DropdownMenu right>
                <DropdownItem header tag='div' className='text-center'>
                  <strong>Chat Room</strong>
                </DropdownItem>
                {this.state.data.map((value, index) => {
                  localStorage.setItem('msgReceiver', value.passenger_email);
                  return (
                    <DropdownItem>
                      {/* <a href='/driver-dashboard/chat/' onClick={this.setRoom(value.room)}>Message sent from {localStorage.getItem('msgReceiver')}</a> */}
                      <Link
                        to={`/driver-dashboard/chat/${localStorage.getItem(
                          'msgReceiver'
                        )}`}
                        onClick={this.setRoom(value.room)}
                      >
                        Message sent from {localStorage.getItem('msgReceiver')}
                      </Link>
                    </DropdownItem>
                  );
                })}
              </DropdownMenu>
            </UncontrolledDropdown>

            <UncontrolledDropdown
              nav
              direction='down'
              style={{ color: 'white' }}
            >
              <DropdownToggle nav style={{ color: 'white' }}>
                <Link to='/driver-dashboard/chat' nav style={{ color: 'white' }}>
                  
                  <i className='cui-envelope-closed'></i>
                </Link>
                {/* <img src={'../../../assets/img/brand/logo.png'} className="img-avatar" alt="Admin" /> */}
              </DropdownToggle>
              {/* <DropdownMenu right>
                <DropdownItem header tag='div' className='text-center'>
                  <strong>All Messages</strong>
                </DropdownItem>
                <DropdownItem>New Messages from..........</DropdownItem>
              </DropdownMenu> */}
            </UncontrolledDropdown>

            <UncontrolledDropdown
              nav
              direction='down'
              style={{ color: 'white' }}
            >
              <DropdownToggle nav style={{ color: 'white' }}>
                <i className='icon-user'></i>
                {/* <img src={'../../../assets/img/brand/logo.png'} className="img-avatar" alt="Admin" /> */}
              </DropdownToggle>
              <DropdownMenu right>
                <DropdownItem header tag='div' className='text-center'>
                  <strong>PROFILE</strong>
                </DropdownItem>
                <Link to='/driver-dashboard/update-profile'>
                  <DropdownItem>
                    <i className='fa fa-user'></i>Update Profile
                  </DropdownItem>
                </Link>
                {/* <DropdownItem>
                  <i className='fa fa-wrench'></i> Settings
                </DropdownItem>
                <DropdownItem>
                  <i className='fa fa-usd'></i> Payments
                </DropdownItem>
                <DropdownItem>
                  <i className='fa fa-shield'></i> Lock Account
                </DropdownItem> */}
                <DropdownItem
                  onClick={(e) => {
                    localStorage.clear();
                    this.props.onLogout(e);
                  }}
                >
                  <i className='fa fa-lock'></i> Logout
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </Nav>
          {/* <AppAsideToggler className="d-md-down-none" /> */}
          {/*<AppAsideToggler className="d-lg-none" mobile />*/}
        </React.Fragment>
      </Header>
    );
  }
}
DefaultHeader.propTypes = propTypes;
DefaultHeader.defaultProps = defaultProps;
DefaultHeader.driverDriver = driverDriver;
export default DefaultHeader;
