import React, { Component } from 'react';
import { Link, NavLink } from 'react-router-dom';
import {
  Badge,
  UncontrolledDropdown,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Nav,
  NavItem,
} from 'reactstrap';
import PropTypes from 'prop-types';
import {
  AppAsideToggler,
  AppNavbarBrand,
  AppSidebarToggler,
} from '@coreui/react';
import logo from '../../assets/img/brand/logo.png';
import sygnet from '../../assets/img/brand/sygnet.svg';
import './style.css';
import Header from '@coreui/react/lib/Header';
import axios from 'axios';
const propTypes = {
  children: PropTypes.node,
};

const defaultProps = {};
class DefaultHeader extends Component {
  state = { admin: null };
  componentDidMount() {
    const token = localStorage.getItem('usertoken');
    axios
      .get('http://localhost:5000/admins/admin_info', {
        headers: {
          'x-auth-token': token,
        },
      })
      .then((user) => {
        console.log(user);
        this.setState({ admin: user.data.admin });
      });
  }
  render() {
    console.log(this.state.admin);
    // eslint-disable-next-line
    const { children, ...attributes } = this.props;
    return (
      <Header className='header'>
        <React.Fragment>
          <AppSidebarToggler className='d-lg-none' display='md' mobile />
          <AppNavbarBrand
            full={{ src: logo, width: 89, height: 25, alt: 'CoreUI Logo' }}
            minimized={{
              src: sygnet,
              width: 30,
              height: 30,
              alt: 'CoreUI Logo',
            }}
          />
          <AppSidebarToggler className='d-md-down-none' display='lg' />
          {/* <Nav className="d-md-down-none" navbar > */}
          {/* <NavItem className="px-3">
            <NavLink to="/dashboard" className="nav-link" style={{color: "white"}}>Dashboard</NavLink>
          </NavItem> */}
          {/* <NavItem className="px-3">
            <Link to="/users" className="nav-link" style={{color: "white"}}>Users</Link>
          </NavItem> */}
          {/* <NavItem className="px-3">
            <NavLink to="#" className="nav-link" style={{color: "white"}}>Settings</NavLink>
          </NavItem> */}
          {/* </Nav> */}
          <Nav className='ml-auto' navbar>
            {this.state.admin !== null && this.state.admin !== undefined ? (
              <h4 style={{ color: 'white' }}>
                {this.state.admin.first_name} {this.state.admin.last_name}
              </h4>
            ) : null}

            {/* <NavItem className='d-md-down-none'>
              <div class='search-container'>
                <form>
                  <input
                    type='text'
                    placeholder='Search..'
                    name='search'
                  ></input>
                  <button type='submit'>
                    <i class='fa fa-search'></i>
                  </button>
                </form>
              </div>
            </NavItem> */}

            {/* <UncontrolledDropdown
              nav
              direction='down'
              style={{ color: 'white' }}
            >
              <DropdownToggle nav style={{ color: 'white' }}>
                <i className='icon-bell'></i>
                <img className="img-avatar" alt="Admin" />
              </DropdownToggle>
              <DropdownMenu right>
                <DropdownItem header tag='div' className='text-center'>
                  <strong>All Notificatios</strong>
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown> */}

            {/* <UncontrolledDropdown
              nav
              direction='down'
              style={{ color: 'white' }}
            >
              <DropdownToggle nav style={{ color: 'white' }}>
                <i className='cui-envelope-closed'></i>
                <img src={'../../../assets/img/brand/logo.png'} className="img-avatar" alt="Admin" />
              </DropdownToggle>
              <DropdownMenu right>
                <DropdownItem header tag='div' className='text-center'>
                  <strong>All Messages</strong>
                </DropdownItem>

                <DropdownItem>New Messages from..........</DropdownItem>
                <DropdownItem>New Messages from..........</DropdownItem>
                <DropdownItem>New Messages from..........</DropdownItem>
                <DropdownItem>New Messages from..........</DropdownItem>
                <DropdownItem>New Messages from..........</DropdownItem>
                <DropdownItem>New Messages from..........</DropdownItem>
                <DropdownItem>New Messages from..........</DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown> */}

            <UncontrolledDropdown
              nav
              direction='down'
              style={{ color: 'white' }}
            >
              <DropdownToggle nav style={{ color: 'white' }}>
                <i className='icon-user'></i>
                {/* <img src={'../../../assets/img/brand/logo.png'} className="img-avatar" alt="Admin" /> */}
              </DropdownToggle>
              <DropdownMenu right>
                <DropdownItem header tag='div' className='text-center'>
                  <strong>PROFILE</strong>
                </DropdownItem>
                {/* <DropdownItem>
                  <i className='fa fa-user'></i> Profile
                </DropdownItem> */}
                {/* <DropdownItem> */}
                  {this.state.admin !== null ? (
                    <div>
                      <Link
                        onClick={() => {
                          localStorage.setItem('adminId', this.state.admin.admin_id);
                        }}
                        to={`/admin-dashboard/admin-edit-profile/${this.state.admin.admin_id}`}
                      >
                        <DropdownItem>
                        <i className='fa fa-user'></i> Update Profile
                        </DropdownItem>
                      </Link>
                    </div>
                  ) : null}
                {/* </DropdownItem> */}

                {/* <DropdownItem>
                  <i className='fa fa-wrench'></i> Settings
                </DropdownItem>
                <DropdownItem>
                  <i className='fa fa-usd'></i> Payments
                </DropdownItem>
                <DropdownItem>
                  <i className='fa fa-shield'></i> Lock Account
                </DropdownItem> */}
                <DropdownItem
                  onClick={(e) => {
                    localStorage.clear();
                    this.props.onLogout(e);
                  }}
                >
                  <i className='fa fa-lock'></i> Logout
                </DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </Nav>
        </React.Fragment>
      </Header>
    );
  }
}
DefaultHeader.propTypes = propTypes;
DefaultHeader.defaultProps = defaultProps;
export default DefaultHeader;
