export default {
  items: [
    {
      name: 'Driver Dashboard',
      url: '/driver-dashboard/driver-dashboard',
      // icon: 'cui-dashboard',
      attributes: {
        exact: true,
      },
    },
    {
      name: 'Start Ride',
      url: '/driver-dashboard/start-ride',
      // icon: 'cui-bell',
      attributes: {
        exact: true,
      },
    },

    {
      name: 'Recent Rides',
      url: '/driver-dashboard/notifications',
      // icon: 'cui-bell',
      attributes: {
        exact: true,
      },
    },

    {
      name: 'Payment',
      url: '/driver-dashboard/messages',
      // icon: 'cui-dollar',
      attributes: {
        exact: true,
      },
    },

    {
      name: 'Chat',
      url: '/driver-dashboard/chat',
      // icon: 'cui-envelope-closed',
      attributes: {
        exact: true,
      },
    },
    // {
    //   name: "Passengers",
    //   url: "/driver-dashboard/passenger",
    //   icon: "cui-user",
    //   attributes: {
    //     exact: true
    //   }
    // },
    // {
    //   name: "Update Location",
    //   url: "/driver-dashboard/updatelocation",
    //   icon: "cui-map",
    //   attributes: {
    //     exact: true
    //   }
    // },
    // // // {
    // // //   name: "Update Time",
    // // //   url: "/driver-dashboard/updatetime",
    // // //   icon: "icon-speedometer",
    // // //   attributes: {
    // // //     exact: true
    // // //   }
    // // },
    // {
    //   name: "Settings",
    //   url: "/driver-dashboard/setting",
    //   icon: "cui-settings",
    //   attributes: {
    //     exact: true
    //   }
    // },
    // // {
    // //   name: "Complaints",
    // //   url: "/driver-dashboard/complaint",
    // //   icon: "cui-pencil",
    // //   attributes: {
    // //     exact: true
    // //   }
    // // }
  ],
};
