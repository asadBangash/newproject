-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 23, 2020 at 12:03 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dts`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `username` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `drivers`
--

CREATE TABLE `drivers` (
  `driver_id` int(11) NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `username` text NOT NULL,
  `contact` text NOT NULL,
  `license_no` text NOT NULL,
  `nic` text NOT NULL,
  `car_model` text NOT NULL,
  `car_no` text NOT NULL,
  `route` text NOT NULL,
  `car_type` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `gender` text NOT NULL,
  `created` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `drivers`
--

INSERT INTO `drivers` (`driver_id`, `first_name`, `last_name`, `username`, `contact`, `license_no`, `nic`, `car_model`, `car_no`, `route`, `car_type`, `email`, `password`, `gender`, `created`) VALUES
(28, 'Mehmood', 'chohan', 'mehmoodc491@gmail.com', '0654656565', 'fgsdg', '5656', '5656', '5656', 'sargodha road', 'tdhggfh', 'mehmood497@gmail.com', '$2b$10$2pBDS6SvGOSgqILCJTTrhObNZ2hC282R7AY0YsQ/95Qo9uCfi.Q.i', 'Male', '2020-08-22 21:26:12');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `driver_email` varchar(50) NOT NULL,
  `passenger_email` varchar(50) NOT NULL,
  `room` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `passengers`
--

CREATE TABLE `passengers` (
  `passenger_id` int(11) NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `username` text NOT NULL,
  `contact` text NOT NULL,
  `gender` text NOT NULL,
  `route` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `created` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `passengers`
--

INSERT INTO `passengers` (`passenger_id`, `first_name`, `last_name`, `username`, `contact`, `gender`, `route`, `email`, `password`, `created`) VALUES
(6, 'Mehmood', 'chohan', 'mehmoodc491@gmail.com', '0654656565', 'Male', 'sargodha road', 'mehmood497@gmail.com', '$2b$10$K/I7tauQuVnDrwMrz3nYjuvTeTsI2bOIlvsazAb/CcPZSef4PghhC', '2020-08-22 21:26:57');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `driver_id` int(11) NOT NULL,
  `passenger_id` int(11) NOT NULL,
  `recepit` varchar(255) NOT NULL,
  `ride_id` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `driver_id`, `passenger_id`, `recepit`, `ride_id`) VALUES
(12, 28, 6, 'https://pay.stripe.com/receipts/acct_1H4kEzL0oartkIMQ/ch_1HJ4LZL0oartkIMQcH98J9kB/rcpt_Hsq1SVQHREduUkfrSTxoXYGaiWWgmQd', '30'),
(13, 28, 6, 'https://pay.stripe.com/receipts/acct_1H4kEzL0oartkIMQ/ch_1HJ4hFL0oartkIMQBA2mOqrB/rcpt_HsqOPBFDZD8jP5ah6f7qEZdnAPIT6lS', '35'),
(14, 28, 6, 'https://pay.stripe.com/receipts/acct_1H4kEzL0oartkIMQ/ch_1HJ4kWL0oartkIMQngVKhJaN/rcpt_HsqRDoIzTB2LeVuUxjtiOv6lBSdeZaV', '36');

-- --------------------------------------------------------

--
-- Table structure for table `rides`
--

CREATE TABLE `rides` (
  `ride_id` int(11) NOT NULL,
  `pickupLocation` text NOT NULL,
  `dropoffLocation` text NOT NULL,
  `numberOfSeats` int(11) NOT NULL,
  `totalPrice` int(11) NOT NULL,
  `driverId` int(11) NOT NULL,
  `passengerId` int(11) NOT NULL,
  `status` text NOT NULL,
  `created` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rides`
--

INSERT INTO `rides` (`ride_id`, `pickupLocation`, `dropoffLocation`, `numberOfSeats`, `totalPrice`, `driverId`, `passengerId`, `status`, `created`) VALUES
(36, 'gujrat', 'lahore', 4, 16, 28, 6, 'placed', '2020-08-22 21:59:43');

-- --------------------------------------------------------

--
-- Table structure for table `startrides`
--

CREATE TABLE `startrides` (
  `driverId` int(11) NOT NULL,
  `startride_id` int(11) NOT NULL,
  `select_pickup_location` varchar(122) NOT NULL,
  `select_dropoff_location` varchar(122) NOT NULL,
  `number_of_seats_available` varchar(122) NOT NULL,
  `enter_price` varchar(122) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `startrides`
--

INSERT INTO `startrides` (`driverId`, `startride_id`, `select_pickup_location`, `select_dropoff_location`, `number_of_seats_available`, `enter_price`) VALUES
(28, 7, 'gujrat', 'lahore', '4', '4');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `drivers`
--
ALTER TABLE `drivers`
  ADD PRIMARY KEY (`driver_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `passengers`
--
ALTER TABLE `passengers`
  ADD PRIMARY KEY (`passenger_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rides`
--
ALTER TABLE `rides`
  ADD PRIMARY KEY (`ride_id`);

--
-- Indexes for table `startrides`
--
ALTER TABLE `startrides`
  ADD PRIMARY KEY (`startride_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `drivers`
--
ALTER TABLE `drivers`
  MODIFY `driver_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `passengers`
--
ALTER TABLE `passengers`
  MODIFY `passenger_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `rides`
--
ALTER TABLE `rides`
  MODIFY `ride_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `startrides`
--
ALTER TABLE `startrides`
  MODIFY `startride_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
