var express = require('express');
var cors = require('cors');
var bodyParser = require('body-parser');
const socketio = require('socket.io');
var app = express();
const server = require('http').createServer(app);
const io = socketio(server);
var port = process.env.PORT || 5000;
require('dotenv').config();
app.use(bodyParser.json());
app.use(cors());
app.use(
  bodyParser.urlencoded({
    extended: false,
  })
);

var users = {};

// Socket
const {
  addUser,
  removeUser,
  getUser,
  getUsersInRoom,
} = require('./utils/user');
io.on('connect', (socket) => {
  socket.on('join', async ({ name, room }, callback) => {
    // console.log('Add USer Data ', addUser({ id: socket.id, name, room }))
    const { error, user } = await addUser({ id: socket.id, name, room });

    if (error) return callback(error);
    // return
    socket.join(user.room);

    socket.emit('message', {
      user: 'admin',
      text: `${user.name}, welcome to private room .`,
    });

    socket.broadcast
      .to(user.room)
      .emit('message', { user: 'admin', text: `${user.name} has joined!` });

    io.to(user.room).emit('roomData', {
      room: user.room,
      users: getUsersInRoom(user.room),
    });
    callback();
  });

  socket.on('sendMessage', (message, callback) => {
    console.log('Message From User', message);
    const user = getUser(socket.id);

    io.to(user.room).emit('message', { user: user.name, text: message });

    callback();
  });

  socket.on('disconnect', () => {
    const user = removeUser(socket.id);

    if (user) {
      io.to(user.room).emit('message', {
        user: 'Admin',
        text: `${user.name} has left.`,
      });
      io.to(user.room).emit('roomData', {
        room: user.room,
        users: getUsersInRoom(user.room),
      });
    }
  });
});

var Drivers = require('./routes/Drivers');

app.use('/drivers', Drivers);

var Passengers = require('./routes/Passengers');

app.use('/passengers', Passengers);

var Admins = require('./routes/Admins');

app.use('/admins', Admins);

var Startrides = require('./routes/Startrides');

app.use('/startrides', Startrides);
const Location = require("./routes/Location.js");

app.use("/location", Location);

const Location2 = require("./routes/Location2");

app.use("/location2", Location2);

if (process.env.NODE_ENV === 'production') {
  app.use(express.static('client/build'));
  app.get('*', (req, res) => {
    const path = require('path');
    res.sendFile(path.resolve(__dirname, 'client', 'build', 'index.html'));
  });
}

server.listen(port, function () {
  console.log('Server is running on port: ' + port);
});
