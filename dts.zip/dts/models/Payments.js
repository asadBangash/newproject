const Sequelize = require('sequelize');
const db = require('../database/db.js');

module.exports = db.sequelize.define(
  'payments',
  {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    driver_id: {
      type: Sequelize.INTEGER,
    },
    passenger_id: {
      type: Sequelize.INTEGER,
    },
    recepit: {
      type: Sequelize.STRING,
    },
    ride_id: {
      type: Sequelize.STRING,
    },
  },
  {
    timestamps: false,
  }
);
