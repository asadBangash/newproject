const Sequelize = require('sequelize')
const db = require('../database/db.js')

module.exports = db.sequelize.define(
  'driver',
  {
    driver_id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    first_name: {
      type: Sequelize.STRING
    },
    last_name: {
      type: Sequelize.STRING
    },
	username: {
      type: Sequelize.STRING
    },
	contact: {
      type: Sequelize.STRING
    },
	license_no: {
      type: Sequelize.STRING
    },
	nic: {
      type: Sequelize.STRING
    },
	car_model: {
      type: Sequelize.STRING
    },
	car_no: {
      type: Sequelize.STRING
    },
	route: {
      type: Sequelize.STRING
    },
	car_type: {
      type: Sequelize.STRING
    },
	
    email: {
      type: Sequelize.STRING
    },

    // email: {
    //   type: Sequelize.STRING,
    //   allowNull: false,
    //   validate: {
    //     isEmail:true
    //   },
    //   unique: {
    //       args: true,
    //       msg: 'Email address already in use!'
    //   }
    // },
    password: {
      type: Sequelize.STRING
    },
	gender: {
      type: Sequelize.STRING
    },
    created: {
      type: Sequelize.DATE,
      defaultValue: Sequelize.NOW
    }
  },
  {
    timestamps: false
  }
)