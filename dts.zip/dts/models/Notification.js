const Sequelize = require('sequelize')
const db = require('../database/db.js')

module.exports = db.sequelize.define(
    'notifications',
    {
        id: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        driver_email: {
            type: Sequelize.STRING
        },
        passenger_email: {
            type: Sequelize.STRING
        },
        room: {
            type: Sequelize.STRING
        }
    },
    {
        timestamps: false
    }
)