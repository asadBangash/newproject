const Sequelize = require('sequelize')
const db = require('../database/db.js')

module.exports = db.sequelize.define(
  'startride',
  {
    startride_id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    select_pickup_location: {
      type: Sequelize.STRING
    },
    select_dropoff_location: {
      type: Sequelize.STRING
    },
	number_of_seats_available: {
      type: Sequelize.STRING
    },
	enter_price: {
      type: Sequelize.STRING
    },
    driverId:{
      type:Sequelize.INTEGER
    }
  },
  {
    timestamps: false
  }
)