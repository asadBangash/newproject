const Sequelize = require('sequelize')
const db = require('../database/db.js')

module.exports = db.sequelize.define(
  'ride',
  {
    ride_id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    pickupLocation: {
      type: Sequelize.STRING
    },
     dropoffLocation: {
      type: Sequelize.STRING
    },
	numberOfSeats: {
      type: Sequelize.STRING
    },
	totalPrice: {
      type: Sequelize.STRING
    },
    driverId:{
      type:Sequelize.INTEGER
    },
    passengerId:{
        type:Sequelize.INTEGER
      },
      status: {
        type: Sequelize.STRING
      },
      created: {
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW
      }
  },
 
  {
    timestamps: false
  }
)