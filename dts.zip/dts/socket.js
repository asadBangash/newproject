const io = require('./server.js').io

module.exports = function(socket){
    console.log('Socket Id'+socket.id)
}