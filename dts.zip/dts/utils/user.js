const Notification = require('../models/Notification');
const Passenger = require('../models/Passenger');
const users = [];

const addUser = async ({ id, name, room }) => {
    try {
        // console.log('Hello New Data', name, room);

        // let splitRoom = room.split("-");
        const notificationData = {
            driver_email: room.split("-")[0],
            passenger_email: room.split("-")[2],
            admin_email: room.split("-")[4],
            room
        };

        const notiData = await Notification.findOne({ where: { room } })
        if (notiData !== null) {
            // name = name.trim().toLowerCase();
            // room = room.trim().toLowerCase();

            // const existingUser = users.find((user) => user.name === name && user.room === room);

            // if (existingUser) {
            //     return { error: 'Username is taken' };
            // }


            const user = { id, name, room };

            // console.log('Not Null', notiData, user, name, room, id);
            users.push(user);

            return { user };

        } else {
            await Notification.create(notificationData);
            name = name.trim().toLowerCase();
            room = room.trim().toLowerCase();

            const existingUser = users.find((user) => user.name === name && user.room === room);

            if (existingUser) {
                return { error: 'Username is taken' };
            }

            const user = { id, name, room };
            console.log('Not Null', notiData, user, name, room, id);


            users.push(user);

            return { user };
        }


    } catch (error) {
        console.log('Add User Catch Error ', error);
    }
}

const removeUser = (id) => {
    const index = users.findIndex((user) => user.id === id);

    if (index !== -1) {
        return users.splice(index, 1)[0];
    }
};

const getUser = (id) => users.find((user) => user.id === id);

const getUsersInRoom = (room) => users.filter((user) => user.room === room);

module.exports = {
    addUser,
    removeUser,
    getUser,
    getUsersInRoom
};