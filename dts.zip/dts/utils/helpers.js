module.exports =   {
   SEND_RESPONSE : ( httpResponse,res) => {
    res.status(httpResponse.output.statusCode).json(httpResponse.output.payload);
 }
}