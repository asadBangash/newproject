const express = require('express')
const startrides = express.Router()

const Startride = require('../models/Startride')
const authenticated = require('../middlewares/authenticated');

startrides.post('/start-ride', authenticated, async (req, res) => {
  req.body.driverId = req.user.driver_id;
  Startride.create(req.body)
    .then(startride => {
      res.json({ status: startride.select_pickup_location + ' Started!' })
    })
    .catch(err => {
      res.send('error: ' + err)
    })
});



startrides.post('/getDriverRide', async (req, res) => {
  try {
    const ride = await Startride.findOne({
      where: {
        select_pickup_location: req.body.pickupLocation,
        select_dropoff_location:req.body.dropoffLocation,
        driverId:req.body.driverId
      }, raw: true
    })
      res.json(ride)
  } catch (error) {
    throw error
  }
});




module.exports = startrides