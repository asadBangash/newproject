const express = require("express");
const router = express.Router();
const Startride = require('../models/Startride')
const Rides = require('../models/Rides')

router.post("/", async (req, res) => {
  try {
    const { id, ride_id } = req.body;
    // const id = req.params.id;
    const getLocation = await Rides.findAll({
      where: {
        passengerId: id,
        // ride_id: ride_id
      },
    });
    console.log(getLocation);
    res.json(getLocation);
  } catch (error) {
    console.log(error);
    res.status(500).send("Error in getting Locations");
  }
});


router.get("/:id1", async (req, res) => {
  try {
    const id1 = req.params.id1;
    const getLocation = await Rides.findAll({
      where: {
        passengerId: id1,
      },
    });

    res.json(getLocation);
  } catch (error) {
    console.error(error);
    res.status(500).send("Error in getting Locations");
  }
});

module.exports = router;
