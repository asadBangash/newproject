const express = require('express');
const passengers = express.Router();
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const Startride = require('../models/Startride');
const Passenger = require('../models/Passenger');
const Driver = require('../models/Driver');
const Payment = require('../models/Payments');
const Ride = require('../models/Rides');
passengers.use(cors());
const Sequelize = require('sequelize');
var stripe = require('stripe')(process.env.stripe_Secret_key);
process.env.SECRET_KEY = 'secret';
const authenticated = require('../middlewares/authenticated');
const { raw } = require('body-parser');
passengers.post('/registerpassenger', (req, res) => {
  const today = new Date();
  const userData = {
    first_name: req.body.first_name,
    last_name: req.body.last_name,
    username: req.body.username,
    contact: req.body.contact,
    gender: req.body.gender,
    route: req.body.route,

    email: req.body.email,
    password: req.body.password,

    created: today,
  };

  Passenger.findOne({
    where: {
      email: req.body.email,
    },
  })
    //TODO bcrypt
    .then((passenger) => {
      if (!passenger) {
        bcrypt.hash(req.body.password, 10, (err, hash) => {
          userData.password = hash;
          Passenger.create(userData)
            .then((passenger) => {
              res.json({ status: passenger.email + ' Registered!' });
            })
            .catch((err) => {
              res.send('error: ' + err);
            });
        });
      } else {
        res.status(400).json({ error: 'User already exists' });
      }
    })
    .catch((err) => {
      res.send('error: ' + err);
    });
});

passengers.post('/passengerlogin', async (req, res) => {
  try {
    let passenger = await Passenger.findOne({
      where: {
        email: req.body.email,
      },
    });

    if (!passenger) {
      res.status(400).send({ error: 'Invalid Credentials' });
    }
    console.log(passenger)
    console.log(req.body.password);
    console.log(passenger.password);
    const isMatch = await bcrypt.compare(req.body.password, passenger.password);
    console.log(isMatch);
    if (isMatch) {
      let token = jwt.sign(passenger.dataValues, process.env.JWTSECRET);
      res.send(token);
    } else {
      res.status(400).json({ error: 'Invalid Credentials' });
    }
  } catch (error) {
    res.status(400).json({ error });
  }


  // console.log(passenger);
  // if (!passenger) {
  //   console.log("NOT PASSENGER");
  //   res.status(400).send({ error: 'Invalid Credentials' });
  // }
  // console.log(req.body.password);
  // console.log("\n");
  // console.log(passenger.password);
  // if (bcrypt.compareSync(req.body.password, passenger.password)) {
  //   let token = jwt.sign(passenger.dataValues, process.env.JWTSECRET);
  //   console.log('Token', token);
  //   res.send(token);
  // } else {
  //   res.status(400).json({ error: 'Invalid Credentials' });
  // }



});

passengers.get('/passenger-dashboard', (req, res) => {
  var decoded = jwt.verify(req.headers['authorization'], process.env.JWTSECRET);

  Passenger.findOne({
    where: {
      passenger_id: decoded.passenger_id,
    },
  })
    .then((passenger) => {
      if (passenger) {
        res.json(passenger);
      } else {
        res.send('User does not exist');
      }
    })
    .catch((err) => {
      res.send('error: ' + err);
    });
});

passengers.post('/driver_search', async (req, res) => {
  try {
    const { pickUp, dropOff } = req.body;
    const driversList = [];
    const ridesList = await Startride.findAll({
      where: {
        [Sequelize.Op.or]: [
          {
            select_pickup_location: { [Sequelize.Op.like]: '%' + pickUp + '%' },
          },
          {
            select_dropoff_location: {
              [Sequelize.Op.like]: '%' + dropOff + '%',
            },
          },
        ],
      },
    });
    ridesList.map((e) => {
      driversList.push(e.driverId);
    });
    const drivers = await Driver.findAll({
      where: {
        driver_id: driversList,
      },
    });
    res.json(drivers);
  } catch (error) {
    throw error;
  }
});

passengers.post('/new_ride', authenticated, async (req, res) => {
  req.body.status = 'placed';
  req.body.passengerId = req.user.passenger_id;
  const ride = await Startride.findOne({
    where: {
      select_pickup_location: req.body.pickupLocation,
      select_dropoff_location: req.body.dropoffLocation,
      driverId: req.body.driverId,
    },
  });
  req.body.totalPrice = ride.enter_price * Number(req.body.numberOfSeats);
  let priceToCharge = req.body.totalPrice * 100;
  Ride.create(req.body)
    .then(async (ride) => {
      const charge = await stripe.charges.create({
        amount: priceToCharge,
        currency: 'usd',
        description: 'Your Ticket Placed Successfully',
        source: req.body.token,
        
        capture: true,
      });
      if (charge) {
        Payment.create({
          ride_id: ride.ride_id,
          driver_id: req.body.driverId,
          passenger_id: req.user.passenger_id,
          recepit: charge.receipt_url,
        });
      }
      console.log(charge);

      res.json({ status: ' Ride Successfully Placed...!' });
    })
    .catch((err) => {
      res.send('error: ' + err);
    });
});

passengers.post('/get_recepits', authenticated, async (req, res) => {
  try {
    const recepits = await Payment.findAll({
      where: {
        passenger_id: req.user.passenger_id,
      },
      raw: true,
    });

    res.json(recepits);
  } catch (error) {
    throw error;
  }
});

passengers.post('/get_recent_rides', authenticated, async (req, res) => {
  try {
    const rides = await Ride.findAll({
      where: {
        passengerId: req.user.passenger_id,
      },
      raw: true,
    });

    res.json(rides);
  } catch (error) {
    throw error;
  }
});

//driver list

passengers.get('/get_drivers', async (req, res) => {
  try {
    const drivers = await Driver.findAll({});

    console.log(drivers);
    res.json(drivers);
  } catch (error) {
    throw error;
  }
});

passengers.get('/getrides', async (req, res) => {
  try {
    const getrides = await Ride.findAll({});

    console.log(getrides);
    res.json(getrides);
  } catch (error) {
    throw error;
  }
});

passengers.get('/getreceipts', async (req, res) => {
  try {
    const receipts = await Payment.findAll({});

    res.json(receipts);
  } catch (error) {
    throw error;
  }
});

//end driver list

passengers.post('/cancel_ride', authenticated, async (req, res) => {
  try {
    const ride = await Ride.update(
      { status: 'Cancelled' },
      {
        where: {
          passengerId: req.user.passenger_id,
          ride_id: req.body.rideId,
        },
      }
    ).then(async (ride) => {
      const rideD = await Ride.findOne({
        where: {
          passengerId: req.user.passenger_id,
          ride_id: req.body.rideId,
        },
        raw: true,
      });
      console.log(rideD.ride_id);
      await Payment.destroy({
        where: {
          ride_id: rideD.ride_id,
        },
      });
      stripe.refunds.create(
        { charge: 'ch_1GduKjCHu9PyRzvSH96b3vdP' },
        function (err, refund) {
          // asynchronously called
        }
      );
    });

    console.log(ride);
  } catch (error) {
    throw error;
  }
});

passengers.get('/onlineUserInfo', authenticated, (req, res) => {
  try {
    res.send(req.user);
  } catch (error) { }
});


passengers.post('/edit_profile', async (req, res) => {
  try {
    const id = req.body.newUser.id;
    const salt = await bcrypt.genSalt(10);

    let password = await bcrypt.hash(req.body.newUser.password, salt);

    Passenger.update(
      {
        first_name: req.body.newUser.first_name,
        last_name: req.body.newUser.last_name,
        username: req.body.newUser.username,
        contact: req.body.newUser.contact,

        route: req.body.newUser.route,

        gender: req.body.newUser.gender,
        email: req.body.newUser.email,
        password
      },
      {
        where: {
          passenger_id: id,
        },
      }
    ).then((trip) => {
      res.status(200).send({ message: 'Your Profile Updated Successfully' });
    });
  } catch (error) {
    throw error;
  }
});

module.exports = passengers;
