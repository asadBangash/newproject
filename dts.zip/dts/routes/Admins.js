const express = require('express');
const admins = express.Router();
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const Admin = require('../models/Admin');
const Passenger = require('../models/Passenger');
const Driver = require('../models/Driver');
const Notification = require('../models/Notification');
const Payment = require('../models/Payments');
const authenticated = require('../middlewares/authenticated');
admins.use(cors());
process.env.SECRET_KEY = 'secret';

admins.post('/registeradmin', (req, res) => {
  // console.log('Req Body', req.body);
  // return
  // const today = new Date()
  const userData = {
    first_name: req.body.first_name,
    last_name: req.body.last_name,
    username: req.body.username,
    email: req.body.email,
    password: req.body.password,
  };
  Admin.findOne({
    where: {
      email: req.body.email,
    },
  })
    //TODO bcrypt
    .then((admin) => {
      if (!admin) {
        bcrypt.hash(req.body.password, 10, (err, hash) => {
          userData.password = hash;
          Admin.create(userData)
            .then((admin) => {
              res.json({ status: admin.email + ' Registered!' });
            })
            .catch((err) => {
              res.send('error: ' + err);
            });
        });
      } else {
        res.status(400).json({ error: 'User already exists' });
      }
    })
    .catch((err) => {
      res.send('error: ' + err);
    });
});
admins.post('/adminlogin', (req, res) => {
  Admin.findOne({
    where: {
      email: req.body.email,
    },
  })
    .then((admin) => {
      if (!admin) {
        res.status(400).send({ error: 'Invalid Credentials' });
      }


      if (bcrypt.compareSync(req.body.password, admin.password)) {
        let token = jwt.sign(admin.dataValues, process.env.JWTSECRET, {
          expiresIn: 1440,
        });
        res.send(token);
      }
      else {
        res.status(400).json({ error: 'User does not exist' });
      }

    })
    .catch((err) => {
      res.status(400).json({ error: err });
    });
});
admins.get('/admin-dashboard', (req, res) => {
  var decoded = jwt.verify(req.headers['authorization'], process.env.JWTSECRET);
  Admin.findOne({
    where: {
      admin_id: decoded.admin_id,
    },
  })
    .then((admin) => {
      if (admin) {
        res.json(admin);
      } else {
        res.send('User does not exist');
      }
    })
    .catch((err) => {
      res.send('error: ' + err);
    });
});

admins.post('/getNotification', async (req, res) => {
  const data = await Notification.findAll({
    where: req.body,
  });
  res.json({
    status: 'success',
    data,
  });
});

// for admin username
// admins.post('/getadmin', async (req, res) => {
//   const getadmin = await Admin.findAll({
//     where: req.body
//   });
//   res.json({
//     status: 'success',
//     getadmin
//   })
// });

admins.get('/getadmin', async (req, res) => {
  try {
    const admin_email = localStorage.getItem('loginUser');

    res.json(admin_email);
  } catch (error) {
    throw error;
  }
});

admins.get('/get_passengers', async (req, res) => {
  try {
    const passengers = await Passenger.findAll({});

    res.json(passengers);
  } catch (error) {
    throw error;
  }
});

admins.get('/get_recepits', async (req, res) => {
  try {
    const recepits = await Payment.findAll({});

    res.json(recepits);
  } catch (error) {
    throw error;
  }
});

admins.get('/totaldrivers', async (req, res) => {
  try {
    const totaldrivers = await Driver.findAndCountAll({});

    res.json(totaldrivers);
  } catch (error) {
    throw error;
  }
});

admins.get('/admin_info', authenticated, async (req, res) => {
  try {
    res.send({ admin: req.user });
  } catch (error) {
    throw error;
  }
});

admins.put('/edit_profile/:id', authenticated, async (req, res) => {
  try {
    const id = req.params.id;
    console.log("ADMIN ID=");
    console.log(id);
    const salt = await bcrypt.genSalt(10);

    let password = await bcrypt.hash(req.body.newUser.password, salt);

    Admin.update(
      {
        first_name: req.body.newUser.first_name,
        last_name: req.body.newUser.last_name,
        username: req.body.newUser.username,
        email: req.body.newUser.email,
        password
      },
      {
        where: {
          admin_id: parseInt(id),
        },
      }
    ).then((trip) => {
      res.status(200).send({ message: 'Your Profile Updated Successfully' });
    });
  } catch (error) {
    throw error;
  }
});

module.exports = admins;
