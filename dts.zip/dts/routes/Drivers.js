const express = require('express');
const drivers = express.Router();
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const Rides = require('../models/Rides');
const Startride = require('../models/Startride');
const Driver = require('../models/Driver');
const Payment = require('../models/Payments');
var stripe = require('stripe')(process.env.stripe_Secret_key);
process.env.SECRET_KEY = 'secret';
const Sequelize = require('sequelize');
drivers.use(cors());
const authenticated = require('../middlewares/authenticated');

drivers.post('/registerdriver', (req, res) => {
  const today = new Date();
  const userData = {
    first_name: req.body.first_name,
    last_name: req.body.last_name,
    username: req.body.username,
    contact: req.body.contact,
    license_no: req.body.license_no,
    nic: req.body.nic,
    car_model: req.body.car_model,
    car_no: req.body.car_no,
    route: req.body.route,
    car_type: req.body.car_type,

    email: req.body.email,
    password: req.body.password,
    gender: req.body.gender,
    created: today,
  };

  Driver.findOne({
    where: {
      email: req.body.email,
    },
  })
    //TODO bcrypt
    .then((driver) => {
      if (!driver) {
        bcrypt.hash(req.body.password, 10, (err, hash) => {
          userData.password = hash;
          Driver.create(userData)
            .then((driver) => {
              res.json({ status: driver.email + ' Registered!' });
            })
            .catch((err) => {
              res.send('error: ' + err);
            });
        });
      } else {
        res.status(400).json({ error: 'User already exists' });
      }
    })
    .catch((err) => {
      res.send('error: ' + err);
    });
});

//update profile
drivers.put('/drivers/:driverId', function (req, res, next) {
  Driver.update(
    { first_name: req.body.first_name },
    { last_name: req.body.last_name },
    { username: req.body.username },
    { contact: req.body.contact },
    { license_no: req.body.license_no },
    { nic: req.body.nic },
    { car_model: req.body.car_model },
    { car_no: req.body.car_no },
    { route: req.body.route },
    { car_type: req.body.car_type },
    { email: req.body.email },
    { password: req.body.password },
    { gender: req.body.gender },
    { where: req.params.driverId }
  )
    .then(function (rowsUpdated) {
      res.json(rowsUpdated);
    })
    .catch(next);
});
//end update

drivers.post('/driverlogin', async (req, res) => {
  console.log('Driver Logiun', req.body);
  await Driver.findOne({
    where: {
      email: req.body.email,
    },
  })
    .then((driver) => {
      if (!driver) {
        res.status(400).send({ error: 'Invalid Credentials' });
      }

      if (bcrypt.compareSync(req.body.password, driver.password)) {
        let token = jwt.sign(driver.dataValues, process.env.JWTSECRET);
        res.send(token);
      } else {
        res.status(400).json({ error: 'Invalid Credentials' });
      }

    })
    .catch((err) => {
      res.status(400).json({ error: err });
    }
    );
});

drivers.get('/driver-dashboard', (req, res) => {
  var decoded = jwt.verify(req.headers['x-auth-token'], process.env.JWTSECRET);

  Driver.findOne({
    where: {
      driver_id: decoded.driver_id,
    },
  })
    .then((driver) => {
      if (driver) {
        res.json(driver);
      } else {
        res.send('User does not exist');
      }
    })
    .catch((err) => {
      res.send('error: ' + err);
    });
});
//payment

drivers.post('/get_recepits', authenticated, async (req, res) => {
  try {
    const recepits = await Payment.findAll({
      where: {
        driver_id: req.user.driver_id,
      },
      raw: true,
    });
    // console.log(recepits);
    res.json(recepits);
  } catch (error) {
    throw error;
  }
});

//end of payment
drivers.get('/get_startrides', async (req, res) => {
  try {
    const startrides = await Startride.findAll({});

    //  console.log(startrides)
    res.json(startrides);
  } catch (error) {
    throw error;
  }
});

drivers.get('/driver_rides', authenticated, async (req, res) => {
  try {
    const ridesList = await Rides.findAll({
      where: { driverId: req.user.driver_id },
      raw: true,
    });
    console.log(ridesList);
    return res.json(ridesList);
  } catch (error) {
    console.log(error);
    throw error;
  }
});

drivers.post('/cancel_ride', authenticated, async (req, res) => {
  try {

    const ride = await Rides.update(
      { status: 'Cancelled' },
      {
        where: {
          driverId: req.user.driver_id,
          ride_id: req.body.rideId,
        },
      }
    ).then(async (ride) => {
      const rideD = await Rides.findOne({
        where: {
          driverId: req.user.driver_id,
          ride_id: req.body.rideId,
        },
        raw: true,
      });
      console.log(rideD.ride_id);
      await Payment.destroy({
        where: {
          ride_id: rideD.ride_id,
        },
      });
      stripe.refunds.create(
        { charge: 'ch_1GduKjCHu9PyRzvSH96b3vdP' },
        function (err, refund) {
          // asynchronously called
        }
      );
    });

    console.log(ride);
  } catch (error) {
    throw error;
  }
});
drivers.post('/complete_ride', authenticated, async (req, res) => {
  try {

    const ride = await Rides.update(
      { status: 'Completed' },
      {
        where: {
          driverId: req.user.driver_id,
          ride_id: req.body.rideId,
        },
      }
    ).then(async (ride) => {
      res.json({ ride });
    });

    console.log(ride);
  } catch (error) {
    throw error;
  }
});

drivers.get('/getdriver', async (req, res) => {
  try {
    const driver_email = localStorage.getItem('loginUser');

    res.json(driver_email);
  } catch (error) {
    throw error;
  }
});

drivers.get('/driver_info', authenticated, async (req, res) => {
  try {
    res.send({ driver: req.user });
  } catch (error) {
    throw error;
  }
});

drivers.post('/edit_profile', async (req, res) => {
  try {
    console.log(req.body.newUser)
    const id = req.body.newUser.id;
    const salt = await bcrypt.genSalt(10);

    let password = await bcrypt.hash(req.body.newUser.password, salt);
    Driver.update(
      {
        first_name: req.body.newUser.first_name,
        last_name: req.body.newUser.last_name,
        username: req.body.newUser.username,
        contact: req.body.newUser.contact,
        license_no: req.body.newUser.license_no,
        nic: req.body.newUser.nic,
        car_model: req.body.newUser.car_model,
        car_no: req.body.newUser.car_no,
        route: req.body.newUser.route,
        car_type: req.body.newUser.car_type,
        gender: req.body.newUser.gender,
        email: req.body.newUser.email,
        password
      },
      {
        where: {
          driver_id: id,
        },
      }
    ).then((trip) => {
      res.status(200).send({ message: 'Your Profile Updated Successfully' });
    });
  } catch (error) {
    throw error;
  }
});

drivers.post('/get_recent_rides', authenticated, async (req, res) => {
  try {
    const rides = await Rides.findAll({
      where: {
        driverId: req.user.driver_id,
      },
      raw: true,
    });

    res.json(rides);
  } catch (error) {
    console.log(error);
    res.status(500).send("Server Error");
  }
});

module.exports = drivers;
